import { NextRequest, NextResponse } from 'next/server';
import { getAll, findWhereContains, sortByDateField, withEmployeeFull, createRecord } from '@/lib/db';
import { verifyPermission, requireAuth } from '@/lib/verify-permission';
import { isValidLegacyDate } from '@/lib/attendance';
import { asScopeViewer, employeeInScope, authScopeViewer, filterRowsByEmployeeScope, resolveEmployeeScopeFromDb } from '@/lib/scope/server';

export async function GET(request: NextRequest) {
  try {
    const auth = await requireAuth(request);
    if (!auth) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const month = searchParams.get('month') || '';
    const status = searchParams.get('status') || '';

    let records = await getAll('attendance');

    // ── READ SCOPE (M0.5) ──
    // Attendance rows are employee-linked: scope is applied at the
    // retrieval boundary, BEFORE search/month/status filters —
    // results are always a subset of AUTHORIZED_SCOPE ∩ FILTER, so
    // search and filters can never widen visibility. Fail-closed
    // for rows without a resolvable stored employeeId.
    const scopeCtx = await resolveEmployeeScopeFromDb(authScopeViewer(auth), undefined, auth.permissions);
    records = filterRowsByEmployeeScope(records as Array<{ employeeId?: string | null }>, scopeCtx);

    if (search) {
      records = records.filter((r: any) =>
        (r.employeeId && r.employeeId.toLowerCase().includes(search.toLowerCase())) ||
        (r.date && r.date.includes(search)) ||
        (r.checkIn && r.checkIn.includes(search)) ||
        (r.checkOut && r.checkOut.includes(search))
      );
    }

    if (month) {
      records = records.filter((r: any) => r.date && r.date.includes(month));
    }

    if (status) {
      records = records.filter((r: any) => r.status === status);
    }

    records = sortByDateField(records, 'date', 'desc');
    const withEmp = await withEmployeeFull(records as any[]);
    return NextResponse.json(withEmp);
  } catch (error) {
    console.error('Fetch attendance error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    // Verify permission: need 'create' on 'attendance'
    const permCheck = await verifyPermission(request, 'attendance', 'create');
    if (!permCheck.allowed) {
      return NextResponse.json({ error: permCheck.error }, { status: 403 });
    }

    const body = await request.json();
    const { employeeId, date, checkIn, checkOut, status, minutesLate, notes } = body;

    if (!employeeId || !date) {
      return NextResponse.json({ error: 'employeeId and date are required' }, { status: 400 });
    }

    // Date-boundary validation (Milestone 2 §22): reject malformed or
    // non-calendar DD/MM/YYYY strings instead of silently storing them.
    if (!isValidLegacyDate(date)) {
      return NextResponse.json({ error: 'صيغة التاريخ غير صحيحة (DD/MM/YYYY مطلوبة)' }, { status: 400 });
    }

    // ── TARGET-EMPLOYEE SCOPE (M0.4) ──
    // The scope check runs BEFORE the existence validation and the
    // create: an out-of-scope target is denied without revealing
    // whether the employee exists. Scope is resolved from the
    // authenticated identity only.
    const inScope = await employeeInScope(
      asScopeViewer(permCheck.user!),
      permCheck.user!.permissions,
      employeeId,
    );
    if (!inScope) {
      return NextResponse.json({ error: 'صلاحية غير كافية' }, { status: 403 });
    }

    // Validate employee exists and is active
    const { validateEmployeeId } = await import('@/lib/validate-employee');
    const empValidation = await validateEmployeeId(employeeId, true);
    if (!empValidation.valid) {
      return NextResponse.json({ error: empValidation.error }, { status: 400 });
    }

    const record = await createRecord('attendance', {
      employeeId, date,
      checkIn: checkIn || null,
      checkOut: checkOut || null,
      status: status || 'present',
      minutesLate: minutesLate || 0,
      notes: notes || null,
    });

    return NextResponse.json(record, { status: 201 });
  } catch (error) {
    console.error('Create attendance error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
