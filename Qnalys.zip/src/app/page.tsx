'use client';

import React from 'react';
import dynamic from 'next/dynamic';
import { AnimatePresence } from 'framer-motion';
import { Skeleton } from '@/components/ui/skeleton';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { NotificationProvider } from '@/contexts/NotificationContext';
import { useAppStore } from '@/lib/store';
import { LanguageProvider } from '@/lib/i18n/language-context';
import { AppLayout } from '@/components/layout/AppLayout';
import { usePermissions } from '@/hooks/usePermissions';
import { APP_PAGES } from '@/config/permissions';
import { AppShell } from '@/components/shell/AppShell';
import LoginPage from '@/components/pages/LoginPage';
import { ShieldX } from 'lucide-react';
import { useMarkSeen } from '@/hooks/use-unseen';
import { QueryCacheIdentityGate } from '@/lib/cache/cache-identity';
import { NavigationHistoryController } from '@/components/navigation/NavigationHistoryController';

// ─── Page skeleton ────────────────────────────────────────────────────────────
function PageSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-10 w-48 rounded-lg bg-slate-800/60" />
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-[120px] rounded-2xl bg-slate-800/40" />
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-[400px] rounded-2xl bg-slate-800/40" />
        ))}
      </div>
    </div>
  );
}

// ─── Lazy pages ───────────────────────────────────────────────────────────────
const HomePage             = dynamic(() => import('@/components/pages/HomePage'),             { loading: () => <PageSkeleton />, ssr: false });
const EmployeesPage        = dynamic(() => import('@/components/pages/EmployeesPage'),        { loading: () => <PageSkeleton />, ssr: false });
const BiometricPage        = dynamic(() => import('@/components/pages/BiometricPage'),        { loading: () => <PageSkeleton />, ssr: false });
const AttendancePage       = dynamic(() => import('@/components/pages/AttendancePage'),       { loading: () => <PageSkeleton />, ssr: false });
const RequestsPage         = dynamic(() => import('@/components/pages/RequestsPage'),         { loading: () => <PageSkeleton />, ssr: false });
const RulesPage            = dynamic(() => import('@/components/pages/RulesPage'),            { loading: () => <PageSkeleton />, ssr: false });
const QualityPage          = dynamic(() => import('@/components/pages/QualityPage'),          { loading: () => <PageSkeleton />, ssr: false });
const HrDeductionsPage     = dynamic(() => import('@/components/pages/HrDeductionsPage'),     { loading: () => <PageSkeleton />, ssr: false });
const TravelPage           = dynamic(() => import('@/components/pages/TravelPage'),           { loading: () => <PageSkeleton />, ssr: false });
const ReportsPage          = dynamic(() => import('@/components/pages/ReportsPage'),          { loading: () => <PageSkeleton />, ssr: false });
const ControlPanelPage     = dynamic(() => import('@/components/pages/ControlPanelPage'),     { loading: () => <PageSkeleton />, ssr: false });
const FollowUpsPage        = dynamic(() => import('@/components/pages/FollowUpsPage'),        { loading: () => <PageSkeleton />, ssr: false });
const CAPAPage             = dynamic(() => import('@/components/pages/CAPAPage'),             { loading: () => <PageSkeleton />, ssr: false });
const ComplaintsPage       = dynamic(() => import('@/components/pages/ComplaintsPage'),       { loading: () => <PageSkeleton />, ssr: false });
const KnowledgeBasePage    = dynamic(() => import('@/components/pages/KnowledgeBasePage'),    { loading: () => <PageSkeleton />, ssr: false });
const RiskCenterPage       = dynamic(() => import('@/components/pages/RiskCenterPage'),       { loading: () => <PageSkeleton />, ssr: false });
const OperationsCenterPage = dynamic(() => import('@/components/pages/OperationsCenterPage'), { loading: () => <PageSkeleton />, ssr: false });
const RulesEnginePage      = dynamic(() => import('@/components/pages/RulesEnginePage'),      { loading: () => <PageSkeleton />, ssr: false });
const WorkflowDesignerPage = dynamic(() => import('@/components/pages/workflow-designer/WorkflowDesignerPage'), { loading: () => <PageSkeleton />, ssr: false });
const QualityDeductionsReportPage = dynamic(() => import('@/components/pages/reports/QualityDeductionsReport'), { loading: () => <PageSkeleton />, ssr: false });
const OrganizationPage     = dynamic(() => import('@/components/pages/organization/OrganizationPage'),          { loading: () => <PageSkeleton />, ssr: false });
const SettingsPage         = dynamic(() => import('@/components/pages/SettingsPage'),                           { loading: () => <PageSkeleton />, ssr: false });
const ProfilePage          = dynamic(() => import('@/components/pages/ProfilePage'),                            { loading: () => <PageSkeleton />, ssr: false });
// ── Quality KPI (Phase 1) ──
const ObservationsPage         = dynamic(() => import('@/components/pages/quality-kpi/ObservationsPage'),         { loading: () => <PageSkeleton />, ssr: false });
const ObservationTemplatesPage  = dynamic(() => import('@/components/pages/quality-kpi/ObservationTemplatesPage'),  { loading: () => <PageSkeleton />, ssr: false });
const KpiDashboardPage         = dynamic(() => import('@/components/pages/quality-kpi/KpiDashboardPage'),         { loading: () => <PageSkeleton />, ssr: false });
const MonthClosePage           = dynamic(() => import('@/components/pages/quality-kpi/MonthClosePage'),           { loading: () => <PageSkeleton />, ssr: false });
const KpiSettingsPage          = dynamic(() => import('@/components/pages/quality-kpi/PerformanceEngineSettingsPage'), { loading: () => <PageSkeleton />, ssr: false });
const QualityAuditLogPage      = dynamic(() => import('@/components/pages/quality-kpi/QualityAuditLogPage'),      { loading: () => <PageSkeleton />, ssr: false });
// ── KPI Reporting Layer (Phase 2) ──
const KpiReportsPage           = dynamic(() => import('@/components/pages/quality-kpi/KpiReportsPage'),           { loading: () => <PageSkeleton />, ssr: false });
// ── Smart Quality Report (Phase 4): presentation-only UI over the
//    existing Performance Intelligence dataset (no new calculations).
const SmartQualityReportPage   = dynamic(() => import('@/components/pages/quality-kpi/smart-report/SmartQualityReportPage'), { loading: () => <PageSkeleton />, ssr: false });
// ── Employee Performance Hub (مركز أداء الموظف): read-only analysis
//    workspace over the canonical engines — no new calculations.
const PerformanceHubPage       = dynamic(() => import('@/components/pages/performance-hub/PerformanceHubPage'), { loading: () => <PageSkeleton />, ssr: false });
const PerformanceHubGroupPage  = dynamic(() => import('@/components/pages/performance-hub/PerformanceHubGroupPage'), { loading: () => <PageSkeleton />, ssr: false });

// ─── Background preload ───────────────────────────────────────────────────────
function PreloadPages() {
  React.useEffect(() => {
    const hasIdle = 'requestIdleCallback' in window;
    const id = hasIdle
      ? window.requestIdleCallback(() => {
          import('@/components/pages/EmployeesPage');
          import('@/components/pages/AttendancePage');
        })
      : window.setTimeout(() => {
          import('@/components/pages/EmployeesPage');
          import('@/components/pages/AttendancePage');
        }, 200);
    return () => {
      if (hasIdle) window.cancelIdleCallback(id as number);
      else clearTimeout(id as number);
    };
  }, []);
  return null;
}

// ─── Access denied ────────────────────────────────────────────────────────────
function AccessDenied() {
  const pageConfig = APP_PAGES.find((p) => p.id === useAppStore.getState().currentPage);
  return (
    <div className="flex flex-col items-center justify-center py-24">
      <div className="w-20 h-20 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center mb-6">
        <ShieldX className="w-10 h-10 text-red-400" />
      </div>
      <h2 className="text-xl font-bold text-slate-200 mb-2">صلاحية غير كافية</h2>
      <p className="text-slate-400 text-center max-w-md">
        ليس لديك صلاحية للوصول إلى {pageConfig?.title || 'هذه الصفحة'}.
        يرجى التواصل مع مدير النظام إذا كنت تعتقد أن هذا خطأ.
      </p>
    </div>
  );
}

// ─── §SIDEBAR-BADGES: mark-on-open ────────────────────────────────────────────
// Opening a monitored page marks THAT module seen for the CURRENT user
// only (per-user state — other users' badges are unaffected). The call
// is optimistic (badge clears instantly) and fires once per navigation;
// the record data itself is fetched by the page as usual.
function MarkSeenOnOpen({ page }: { page: string }) {
  const markSeen = useMarkSeen();
  React.useEffect(() => {
    markSeen(page);
    // One mark per navigation — the page id is the dependency.
  }, [page]);
  return null;
}

// ─── Page router ──────────────────────────────────────────────────────────────
function PageRouter() {
  const currentPage = useAppStore((s) => s.currentPage);
  const { canViewPage } = usePermissions();

  // §USER-PROFILE — 'profile' is admitted like 'home': every
  // authenticated user owns their profile, and /api/profile is
  // self-scoped server-side (requireAuth), so there is nothing to
  // escalate. Everything else stays permission-gated.
  if (
    currentPage !== 'home' &&
    currentPage !== 'profile' &&
    !canViewPage(currentPage)
  ) {
    return <AccessDenied key="access-denied" />;
  }

  return (
    <>
      <MarkSeenOnOpen page={currentPage} />
      {renderPage(currentPage)}
    </>
  );
}

function renderPage(currentPage: string): React.ReactNode {
  switch (currentPage) {
    case 'home':             return <HomePage             key="home" />;
    case 'employees':        return <EmployeesPage        key="employees" />;
    case 'biometric':        return <BiometricPage        key="biometric" />;
    case 'attendance':       return <AttendancePage       key="attendance" />;
    case 'requests':         return <RequestsPage         key="requests" />;
    case 'rules':            return <RulesPage            key="rules" />;
    case 'quality':          return <QualityPage          key="quality" />;
    case 'hrDeductions':     return <HrDeductionsPage     key="hrDeductions" />;
    case 'travel':           return <TravelPage           key="travel" />;
    case 'reports':          return <ReportsPage          key="reports" />;
    case 'qualityDeductionsReport': return <QualityDeductionsReportPage key="qualityDeductionsReport" />;
    case 'controlPanel':     return <ControlPanelPage     key="controlPanel" />;
    case 'organization':     return <OrganizationPage     key="organization" />;
    case 'settings':         return <SettingsPage         key="settings" />;
    case 'profile':          return <ProfilePage          key="profile" />;
    case 'followUps':        return <FollowUpsPage        key="followUps" />;
    case 'capa':             return <CAPAPage             key="capa" />;
    case 'complaints':       return <ComplaintsPage       key="complaints" />;
    case 'knowledgeBase':    return <KnowledgeBasePage    key="knowledgeBase" />;
    case 'riskCenter':       return <RiskCenterPage       key="riskCenter" />;
    case 'operationsCenter': return <OperationsCenterPage key="operationsCenter" />;
    // §NOTIFICATIONS-V2: no 'notifications' case — the standalone page
    // was removed; store.navigateTo intercepts the id and opens the
    // Header bell panel instead.
    case 'rulesEngine':      return <RulesEnginePage      key="rulesEngine" />;
    case 'workflowDesigner': return <WorkflowDesignerPage key="workflowDesigner" />;
    // ── Quality KPI (Phase 1) ──
    case 'observations':          return <ObservationsPage          key="observations" />;
    // §SETTINGS-CENTER — the legacy categories page id routes INTO the
    // Settings Center (Master Data domain, deep-linked). The registry
    // entry + permission key are unchanged, so existing grants keep
    // working with exactly ONE settings UI.
    case 'observationCategories':
      return <SettingsPage key="observationCategories" initialSection="masterData" initialDomain="observationCategories" routePageId="observationCategories" />;
    case 'observationTemplates':  return <ObservationTemplatesPage  key="observationTemplates" />;
    case 'kpiDashboard':          return <KpiDashboardPage          key="kpiDashboard" />;
    case 'kpiReports':            return <KpiReportsPage            key="kpiReports" />;
    case 'smartQualityReport':    return <SmartQualityReportPage    key="smartQualityReport" />;
    case 'employeePerformanceHub': return <PerformanceHubPage       key="employeePerformanceHub" />;
    case 'employeePerformanceHubGroup': return <PerformanceHubGroupPage key="employeePerformanceHubGroup" />;
    case 'monthClose':            return <MonthClosePage            key="monthClose" />;
    case 'kpiSettings':           return <KpiSettingsPage           key="kpiSettings" />;
    case 'qualityAuditLog':       return <QualityAuditLogPage       key="qualityAuditLog" />;
    default:                      return <HomePage                  key="home" />;
  }
}

// ─── App content ──────────────────────────────────────────────────────────────
// Rendered inside AppShell's z-10 layer.
// AppShell handles the loading overlay (z-20) independently.
// This component only manages the login ↔ ready transition.
function AppContent() {
  const { user, loading } = useAuth();

  // While loading, render nothing — AppShell's LoadingOverlay covers the screen.
  // Once loading resolves, animate in either login or the app.
  if (loading) return null;

  return (
    <>
      {/* §CACHE-IDENTITY — user isolation + authorization-context
          invalidation for the singleton query cache. Must render on
          BOTH sides of the login transition to catch logout. */}
      <QueryCacheIdentityGate />
      {/* §NAVIGATION-HISTORY — browser History API integration
          (Back/Forward/mobile Back stay inside Qnalys, page-state
          continuity, identity boundaries). Also renders on BOTH
          sides of the login transition. */}
      <NavigationHistoryController />
      <PreloadPages />

      {/* Login overlay — fades in/out above the persistent background */}
      <AnimatePresence>
        {!user && <LoginPage key="login" />}
      </AnimatePresence>

      {/* App — mounts after login, unmounts on logout */}
      {user && (
        <NotificationProvider>
          <AppLayout>
            <PageRouter />
          </AppLayout>
        </NotificationProvider>
      )}
    </>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────
export default function Home() {
  return (
    <LanguageProvider>
      <AuthProvider>
      {/*
       * AppShell mounts once. It owns:
       *   - PersistentBackground (z-0, React.memo, never re-renders)
       *   - LoadingOverlay       (z-20, AnimatePresence, fades out after session check)
       *
       * AppContent (z-10) manages login ↔ ready with its own AnimatePresence.
       * The two AnimatePresence instances are siblings, not nested.
       */}
      <AppShell>
        <AppContent />
      </AppShell>
      </AuthProvider>
    </LanguageProvider>
  );
}
