'use client';

// ══════════════════════════════════════════════════════════════
//  KPI Reports UI — shared helpers, badges & export (Phase 2)
//
//  CLIENT-SAFE ONLY: this file must never import the server-side
//  kpi-reporting barrel (it would pull the Firebase admin layer into
//  the client bundle). Report shapes are imported TYPE-ONLY — types
//  are erased at build time.
// ══════════════════════════════════════════════════════════════

import { authFetch } from '@/lib/api-fetch';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import type { KpiValueBasis } from '@/lib/kpi-reporting';
import { useLanguage } from '@/lib/i18n/language-context';
import { translateUIText } from '@/lib/i18n/ui-text';
import { presentStatus } from '@/lib/i18n/presentation';
import { formatMonthKey, formatNumber, formatPercentage } from '@/lib/i18n/format';
import type { Locale } from '@/lib/i18n/dictionary';

// ─────────────────────────────────────────────────────────────
//  Month formatting (same convention as MonthClosePage)
// ─────────────────────────────────────────────────────────────

export const MONTH_LABELS_AR = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
];

export function formatMonth(monthKey: string): string {
  const [y, m] = monthKey.split('-');
  const idx = parseInt(m, 10) - 1;
  if (idx < 0 || idx > 11) return monthKey;
  return `${MONTH_LABELS_AR[idx]} ${y}`;
}

export function currentMonthKey(now: Date = new Date()): string {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

export interface MonthOption {
  value: string;
  label: string;
  closed: boolean;
}

/**
 * Month dropdown options: the current calendar month plus every
 * month that has a snapshot document (closed or reopened), newest
 * first. Closed months carry a frozen marker (spec §8).
 */
export function buildMonthOptions(
  snapshots: Array<{ monthKey: string; status: 'open' | 'closed' }> | undefined,
  locale?: Locale,
): MonthOption[] {
  const current = currentMonthKey();
  const seen = new Map<string, boolean>();
  seen.set(current, seen.get(current) ?? false);
  for (const snap of snapshots ?? []) {
    if (!snap?.monthKey) continue;
    seen.set(snap.monthKey, seen.get(snap.monthKey) ?? snap.status === 'closed');
  }
  return [...seen.entries()]
    .sort((a, b) => b[0].localeCompare(a[0]))
    .slice(0, 24)
    .map(([value, closed]) => ({
      value,
      label: `${formatMonthKey(value, locale)}${closed ? ' 🔒' : ''}`,
      closed,
    }));
}

// ─────────────────────────────────────────────────────────────
//  §12  Status badges — every state visually distinguishable
// ─────────────────────────────────────────────────────────────

const STATUS_STYLES: Record<string, string> = {
  FINALIZED: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
  AVAILABLE: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  INCOMPLETE: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  PENDING: 'bg-slate-500/15 text-slate-300 border-slate-500/30',
  ZERO: 'bg-red-500/15 text-red-300 border-red-500/30',
  NOT_ELIGIBLE: 'bg-slate-600/20 text-slate-400 border-slate-600/40',
  NO_SCHEME: 'bg-brand-500/15 text-brand-300 border-brand-500/30',
  AMBIGUOUS: 'bg-brand-500/15 text-brand-300 border-brand-500/30',
  OVERRIDE_NOT_RESOLVABLE: 'bg-brand-500/15 text-brand-300 border-brand-500/30',
  COMPLETE: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
};

const STATUS_LABELS: Record<string, [string, string]> = {
  FINALIZED: ['مجمّد', 'Frozen'],
  AVAILABLE: ['متاح', 'Available'],
  INCOMPLETE: ['غير مكتمل', 'Incomplete'],
  PENDING: ['معلّق', 'Suspended'],
  ZERO: ['صفر', 'Zero'],
  NOT_ELIGIBLE: ['غير مؤهل', 'Ineligible'],
  NO_SCHEME: ['لا يوجد مخطط', 'No scheme'],
  AMBIGUOUS: ['مخططات متعددة', 'Multiple schemes'],
  OVERRIDE_NOT_RESOLVABLE: ['تجاوز غير قابل للتطبيق', 'Unresolvable override'],
  COMPLETE: ['مكتمل', 'Completed'],
};

export function StatusBadge({ status, className }: { status: string | null; className?: string }) {
  const { locale } = useLanguage();
  if (!status) return <span className="text-slate-500">—</span>;
  const label = STATUS_LABELS[status]?.[locale === 'en' ? 1 : 0]
    // §PRESENTATION-BOUNDARY — unknown engine keys resolve to the safe
    // generic label; the raw key never becomes visible text.
    ?? presentStatus(status, locale);
  return (
    <Badge
      variant="outline"
      className={cn('text-[11px] whitespace-nowrap', STATUS_STYLES[status] ?? 'bg-slate-500/15 text-slate-300 border-slate-500/30', className)}
      // The visible text is the localized business label; the raw
      // engine key stays an explicit hover diagnostic (title) only.
      title={STATUS_LABELS[status] ? status : undefined}
    >
      {label}
    </Badge>
  );
}

const BASIS_LABELS: Record<KpiValueBasis | 'MIXED', [string, string]> = {
  MTD: ['MTD — حتى تاريخه', 'MTD — month to date'],
  LIVE: ['حية (غير نهائية)', 'Live (non-final)'],
  FINALIZED: ['مجمّدة نهائية', 'Finalized'],
  // §FLEX-PERIODS — a span mixing frozen + live months.
  MIXED: ['مختلطة — مجمّدة وحية', 'Mixed — frozen + live'],
};

const BASIS_STYLES: Record<KpiValueBasis | 'MIXED', string> = {
  MTD: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30',
  LIVE: 'bg-orange-500/15 text-orange-300 border-orange-500/30',
  MIXED: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  FINALIZED: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
};

export function ValueBasisBadge({ basis }: { basis: KpiValueBasis | 'MIXED' }) {
  const { locale } = useLanguage();
  const label = BASIS_LABELS[basis];
  return (
    <Badge variant="outline" className={cn('text-[11px] whitespace-nowrap', BASIS_STYLES[basis])}>
      {locale === 'en' ? label[1] : label[0]}
    </Badge>
  );
}

// ─────────────────────────────────────────────────────────────
//  Number formatting
// ─────────────────────────────────────────────────────────────

export function formatScore(value: number | null | undefined, locale?: Locale): string {
  if (value === null || value === undefined) return '—';
  const rounded = Math.round(value * 100) / 100;
  return formatPercentage(rounded, { locale, maximumFractionDigits: 2 });
}

export function formatContribution(value: number | null | undefined, max: number | null | undefined, locale?: Locale): string {
  if (value === null || value === undefined) return '—';
  const rounded = Math.round(value * 100) / 100;
  return max === null || max === undefined
    ? formatNumber(rounded, { locale })
    : `${formatNumber(rounded, { locale })} / ${formatNumber(max, { locale })}`;
}

export function formatSignedPoints(value: number, locale?: Locale): string {
  const rounded = Math.round(value * 100) / 100;
  if (value > 0) return `+${formatNumber(rounded, { locale })}`;
  return formatNumber(rounded, { locale });
}

// ─────────────────────────────────────────────────────────────
//  §22  Excel export — SAME verified numbers as on screen
// ─────────────────────────────────────────────────────────────

/**
 * Download one of the registered KPI reports as Excel through the
 * unified /api/reports/run endpoint (definition-driven workbook).
 * The server re-applies permission + authorized scope — the client
 * can never widen the data.
 */
export async function downloadKpiReportExcel(
  reportId: string,
  body: Record<string, unknown>,
  fileName: string,
  locale: 'ar' | 'en' = 'ar',
): Promise<void> {
  // §INPUT-TYPES — the payload is an open-ended record (the run
  // endpoint accepts per-report filter envelopes); typed explicitly
  // so the spread keeps its index signature.
  const payload: Record<string, unknown> = { ...body, lang: locale };
  if (payload.filters && typeof payload.filters === 'object') {
    // Drop empty filter envelopes instead of sending noise.
    if (Object.keys(payload.filters as Record<string, unknown>).length === 0) {
      delete payload.filters;
    }
  }
  const res = await authFetch('/api/reports/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reportId, format: 'excel', ...payload }),
  });
  if (!res.ok) {
    let message = translateUIText('فشل تصدير التقرير');
    try {
      const parsed = await res.json();
      message = parsed?.error?.message ?? message;
    } catch {
      // non-JSON error body — keep the default message
    }
    throw new Error(message);
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}
