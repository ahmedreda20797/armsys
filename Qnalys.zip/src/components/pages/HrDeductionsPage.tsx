'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { usePermissions } from '@/hooks/usePermissions';
import { usePageState } from '@/hooks/use-page-state';
import { useRecordHighlight } from '@/hooks/use-record-highlight';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { EmployeeLink } from '@/components/shared/EmployeeLink';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
// §EVIDENCE-ITEMS — unified evidence collection + read-only view
import { EvidenceCollectionInput, EvidenceSummaryButton } from '@/components/shared/evidence';
import { isCompleteEvidenceItem, normalizeEvidenceItems } from '@/lib/evidence-items';
import type { EvidenceItem } from '@/types';
import {
  Banknote,
  Plus,
  Check,
  X,
  Clock,
  Search,
  Pencil,
  Trash2,
  ShieldAlert,
  Loader2,
  CalendarDays,
  Archive,
} from 'lucide-react';
import { toast } from 'sonner';
import { ConfirmDialog } from '@/components/shared/ConfirmDialog';
import { SmartActionMenu } from '@/components/shared/SmartActionMenu';
import { EmployeeSearchInput } from '@/components/shared/EmployeeSearchInput';
import type { HrDeduction, Employee } from '@/types';
import { useAppStore } from '@/lib/store';
import { useAuth } from '@/contexts/AuthContext';
import { apiFetch } from '@/lib/api-fetch';
import { useQueryClient } from '@tanstack/react-query';
import { useHrDeductionsList, useEmployees, useDashboardUsers } from '@/hooks/use-queries';
import { invalidateDomain } from '@/lib/cache/invalidation';
import { DataFreshnessIndicator } from '@/components/shared/DataFreshnessIndicator';
import { T } from '@/lib/i18n/T';
import { translateUIText } from '@/lib/i18n/ui-text';
import { useLanguage } from '@/lib/i18n/language-context';
import { formatInteger, formatNumber, formatMonthKey } from '@/lib/i18n/format';
import { currentMonthKey } from '@/lib/date-utils';
import { PagePeriodIndicator } from '@/components/shared/PagePeriodIndicator';
import { PageHeaderBar } from '@/components/shared/PageHeaderBar';
import { CAPALinkBadge } from '@/components/shared/CAPALinkBadge';
import { CAPAInlineForm, type CapaInlineFormState } from '@/components/shared/inline-forms';
import { InlineFormPanel } from '@/components/shared/InlineFormPanel';

const DEDUCTION_TYPES = [
  { value: 'خصم تأخير', label: 'خصم تأخير' },
  { value: 'خصم غياب', label: 'خصم غياب' },
  { value: 'خصم جودة', label: 'خصم جودة' },
  { value: 'خصم آخر', label: 'خصم آخر' },
];

function generateMonthOptions(): { value: string; label: string }[] {
  const now = new Date();
  const options: { value: string; label: string }[] = [];
  for (let i = -1; i <= 3; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
    const value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const months = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
    ];
    const label = `${months[d.getMonth()]} ${d.getFullYear()}`;
    options.push({ value, label });
  }
  return options;
}

const MONTH_OPTIONS = generateMonthOptions();

function getTodayDate(): string {
  const now = new Date();
  return `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()}`;
}

interface HrDeductionWithEmployee extends HrDeduction {
  employeeName: string;
  employeeDepartment: string | null;
}

const EMPTY_FORM = {
  employeeId: '',
  type: 'خصم تأخير',
  amount: '',
  unit: 'EGP' as 'days' | 'EGP',
  month: MONTH_OPTIONS[1]?.value || MONTH_OPTIONS[0]?.value || '',
  reason: '',
  deductionDate: '',
  evidenceItems: [] as EvidenceItem[],
};

export default function HrDeductionsPage() {
  const { canEdit, canCreate, canUpdate, canDelete, canApprove } = usePermissions('hrDeductions');
  const { locale } = useLanguage();
  // §12 GLOBAL INLINE FORM STANDARD — "إنشاء CAPA" from an approved HR
  // violation opens the shared inline CAPA form HERE (gated by CAPA's
  // own create permission); it never navigates to the CAPA page.
  const { canCreate: canCreateCapa } = usePermissions('capa');
  const { user } = useAuth();
  // Phase 6.3 (§8): filter context persists per user (session-scoped).
  // Milestone 7 §13: period filter added — DEFAULT = CURRENT MONTH
  // (no persisted state only, §27); 'all' stays selectable. Version
  // bumped to 2: the shape grows monthFilter and old state orphans
  // cleanly instead of silently missing the field.
  const [hrView, setHrView] = usePageState<{
    showArchived?: boolean;
    search: string;
    statusFilter: 'all' | 'pending' | 'approved' | 'rejected';
    monthFilter: string;
  }>({
    page: 'hrDeductions',
    slot: 'filters',
    version: 2,
    initial: () => ({ search: '', statusFilter: 'all', monthFilter: currentMonthKey() }),
    validate: (raw) =>
      raw && typeof raw === 'object' && !Array.isArray(raw)
        && typeof (raw as { monthFilter?: unknown }).monthFilter === 'string'
        ? raw
        : null,
  });
  const search = hrView.search;
  const setSearch = (v: string) => setHrView((s) => ({ ...s, search: v }));
  const statusFilter = hrView.statusFilter;
  const setStatusFilter = (v: 'all' | 'pending' | 'approved' | 'rejected') =>
    setHrView((s) => ({ ...s, statusFilter: v }));
  const monthFilter = hrView.monthFilter;
  const setMonthFilter = (v: string) => setHrView((s) => ({ ...s, monthFilter: v }));
  // §ARCHIVE — optional historical view of archived HR deductions.
  const showArchived = hrView.showArchived === true;
  const setShowArchived = (v: boolean) => setHrView((s) => ({ ...s, showArchived: v }));
  // ═══ DATA STATE (cache-backed, §4) — archived/live are distinct
  //  cache entries; toggling restores the other snapshot instantly.
  const queryClient = useQueryClient();
  const deductionsQuery = useHrDeductionsList(showArchived);
  const employeesQuery = useEmployees();
  const systemUsersQuery = useDashboardUsers('basic');
  const deductions = deductionsQuery.data ?? [];
  const employees = employeesQuery.data ?? [];
  const systemUsers = systemUsersQuery.data ?? [];
  const loading = deductionsQuery.isLoading || employeesQuery.isLoading;
  const revalidating = (deductionsQuery.isFetching || employeesQuery.isFetching) && !loading;
  // Phase 6.1 (Global Search §8): exact-record deep-link highlight via
  // the shared evidence mechanism — records carry data-record-id below.
  useRecordHighlight({ ready: !loading });
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [reviewing, setReviewing] = useState(false);
  const [addForm, setAddForm] = useState({ ...EMPTY_FORM });
  const [editForm, setEditForm] = useState({ ...EMPTY_FORM, id: '' });
  const [capaCreating, setCapaCreating] = useState<string | null>(null);
  // §12 — inline CAPA creation from an approved HR violation.
  const [capaPrefill, setCapaPrefill] = useState<Partial<CapaInlineFormState> | null>(null);

  // ═══ Manual refresh / mutation revalidation (§26).
  const refreshData = useCallback(async () => {
    await invalidateDomain(queryClient, 'hrDeductions');
  }, [queryClient]);

  const handleAdd = async () => {
    if (!addForm.employeeId || !addForm.type || !addForm.amount || !addForm.unit || !addForm.month) return;
    // §20 — per-item evidence validation before any network work.
    if (addForm.evidenceItems.some((it) => !isCompleteEvidenceItem(it))) {
      toast.error(translateUIText('أكمل بيانات الأدلة غير المكتملة أو أزلها قبل الحفظ', locale));
      return;
    }
    setSaving(true);
    try {
      await apiFetch('/api/hr-deductions', {
        method: 'POST',
        body: JSON.stringify({
          employeeId: addForm.employeeId,
          type: addForm.type,
          amount: Number(addForm.amount),
          unit: addForm.unit,
          month: addForm.month,
          reason: addForm.reason,
          deductionDate: addForm.deductionDate || null,
          evidenceItems: addForm.evidenceItems,
        }),
      });
      await invalidateDomain(queryClient, 'hrDeductions', { employeeId: addForm.employeeId });
      setIsAddOpen(false);
      setAddForm({ ...EMPTY_FORM });
    } catch {
      // Error handled silently
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = async () => {
    if (!editForm.id) return;
    // §20 — per-item evidence validation before any network work.
    if (editForm.evidenceItems.some((it) => !isCompleteEvidenceItem(it))) {
      toast.error(translateUIText('أكمل بيانات الأدلة غير المكتملة أو أزلها قبل الحفظ', locale));
      return;
    }
    setSaving(true);
    try {
      await apiFetch(`/api/hr-deductions/${editForm.id}`, {
        method: 'PATCH',
        body: JSON.stringify({
          type: editForm.type,
          amount: Number(editForm.amount),
          unit: editForm.unit,
          month: editForm.month,
          reason: editForm.reason,
          deductionDate: editForm.deductionDate || null,
          evidenceItems: editForm.evidenceItems,
        }),
      });
      await invalidateDomain(queryClient, 'hrDeductions', { employeeId: editForm.employeeId });
      setIsEditOpen(false);
      setEditForm({ ...EMPTY_FORM, id: '' });
    } catch {
      // Error handled silently
    } finally {
      setSaving(false);
    }
  };

  const handleReview = async (id: string, status: 'approved' | 'rejected') => {
    setReviewing(true);
    try {
      const ded = deductions.find((d: any) => d.id === id);
      await apiFetch(`/api/hr-deductions/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status, approvedBy: user?.id }),
      });
      await invalidateDomain(queryClient, 'hrDeductions', { employeeId: ded?.employeeId });
    } catch {
      // Error handled silently
    } finally {
      setReviewing(false);
    }
  };

  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [archivingId, setArchivingId] = useState<string | null>(null);
  const [archiveLoading, setArchiveLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // §ARCHIVE — archive/restore an HR deduction (audited server-side).
  // Archived = historical: excluded from every active total.
  const handleArchive = async (id: string, archived: boolean) => {
    setArchiveLoading(true);
    try {
      const ded = deductions.find((d: any) => d.id === id);
      await apiFetch(`/api/hr-deductions/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ archived }),
      });
      toast.success(archived ? translateUIText('تم أرشفة الخصم — لن يأثر على الإجماليات النشطة', locale) : translateUIText('تم استعادة الخصم من الأرشيف', locale));
      setArchivingId(null);
      await invalidateDomain(queryClient, 'hrDeductions', { employeeId: ded?.employeeId });
    } catch (err: any) {
      toast.error(err?.message || translateUIText('تعذّر الاتصال بالخادم', locale));
    } finally {
      setArchiveLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    setDeleteLoading(true);
    try {
      const ded = deductions.find((d: any) => d.id === id);
      await apiFetch(`/api/hr-deductions/${id}`, { method: 'DELETE' });
      setDeletingId(null);
      await invalidateDomain(queryClient, 'hrDeductions', { employeeId: ded?.employeeId });
    } catch {
      // Error handled silently
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleCreateCapa = async (ded: HrDeductionWithEmployee) => {
    setCapaCreating(ded.id);
    try {
      await apiFetch(`/api/hr-deductions/${ded.id}/create-capa`, {
        method: 'POST',
        body: JSON.stringify({}),
      });
      await invalidateDomain(queryClient, 'hrDeductions', { employeeId: ded.employeeId });
    } catch {
      // Error handled silently
    } finally {
      setCapaCreating(null);
    }
  };

  const openEditDialog = (deduction: HrDeductionWithEmployee) => {
    setEditForm({
      id: deduction.id,
      employeeId: deduction.employeeId,
      type: deduction.type,
      amount: String(deduction.amount),
      unit: deduction.unit,
      month: deduction.month,
      reason: deduction.reason,
      deductionDate: deduction.deductionDate || '',
      // §EVIDENCE-ITEMS — read adapter (HR deductions carry no legacy
      // evidence fields; stored items pass through).
      evidenceItems: normalizeEvidenceItems(deduction, 'none'),
    });
    setIsEditOpen(true);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-amber-500/15 text-amber-400 border-amber-500/20"><T>معلق</T></Badge>;
      case 'approved':
        return <Badge className="bg-green-500/15 text-green-400 border-green-500/20"><T>مقبول</T></Badge>;
      case 'rejected':
        return <Badge className="bg-red-500/15 text-red-400 border-red-500/20"><T>مرفوض</T></Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Locale-aware unit word for the stored unit code (app-owned vocabulary,
  // never user data): [ar, en] picked at render by the active locale.
  const getUnitLabel = (unit: string): string => {
    const [ar, en] = unit === 'days' ? ['يوم', 'days'] : ['جنيه', 'EGP'];
    return locale === 'en' ? en : ar;
  };

  // Filtering — Milestone 7 §13: the period filter (month) applies to
  // BOTH sections; 'all' shows every month. Calculations untouched.
  const filtered = deductions.filter((d) => {
    const matchesSearch =
      (d.employeeName || '').toLowerCase().includes(search.toLowerCase()) ||
      d.month.includes(search) ||
      d.type.includes(search);
    const matchesStatus = statusFilter === 'all' || d.status === statusFilter;
    const matchesMonth = monthFilter === 'all' || d.month === monthFilter;
    return matchesSearch && matchesStatus && matchesMonth;
  });

  const pending = filtered.filter((d) => d.status === 'pending');
  const other = filtered.filter((d) => d.status !== 'pending');
  const allPendingCount = deductions.filter((d) => d.status === 'pending').length;

  const filterTabs = [
    { key: 'all' as const, label: 'الكل', count: deductions.length },
    { key: 'pending' as const, label: 'معلق', count: allPendingCount },
    { key: 'approved' as const, label: 'مقبول', count: deductions.filter((d) => d.status === 'approved').length },
    { key: 'rejected' as const, label: 'مرفوض', count: deductions.filter((d) => d.status === 'rejected').length },
  ];

  return (
    <div className="space-y-6">
      {/* Header (§25/§26 — sticky, primary action always accessible) */}
      <PageHeaderBar
        icon={<Banknote className="size-5" />}
        iconClassName="bg-brand-500/15 border-brand-500/30 text-brand-400"
        title={translateUIText('خصومات الموارد البشرية', locale)}
        description={<>{formatInteger(allPendingCount, locale)} <T>خصم معلق</T></>}
        extras={
          <PagePeriodIndicator
            testId="hr-period-indicator"
            label={monthFilter === 'all' ? translateUIText('كل الأشهر', locale) : formatMonthKey(monthFilter, locale)}
            filtered={monthFilter !== 'all'}
            onShowAll={() => setMonthFilter('all')}
          />
        }
        primaryAction={canCreate ? {
          label: translateUIText('إضافة خصم', locale),
          onClick: () => { setIsAddOpen(true); setAddForm({ ...EMPTY_FORM, deductionDate: getTodayDate() }); },
        } : undefined}
      />

      {/* Search + period filter (§13 — visible outside any collapsed panel) */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative max-w-md flex-1 min-w-[240px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
          <Input
            placeholder={translateUIText('بحث باسم الموظف أو الشهر أو النوع...', locale)}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-slate-800 border-slate-600 text-white pr-10 placeholder:text-slate-500"
          />
        </div>
        <Select value={monthFilter} onValueChange={setMonthFilter}>
          <SelectTrigger className="bg-slate-800/70 border-slate-700/70 text-white w-40 h-10 text-sm">
            <CalendarDays className="size-3.5 ml-1.5 text-slate-500" />
            <SelectValue placeholder={translateUIText('الشهر', locale)} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all" className="text-white"><T>كل الأشهر</T></SelectItem>
            {MONTH_OPTIONS.map((m) => (
              <SelectItem key={m.value} value={m.value} className="text-white">{formatMonthKey(m.value, locale)}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {/* §ARCHIVE — optional historical view */}
        <button
          type="button"
          onClick={() => setShowArchived(!showArchived)}
          aria-pressed={showArchived}
          className={`inline-flex items-center gap-1.5 px-3 h-10 rounded-lg border text-xs font-medium transition-colors ${
            showArchived
              ? 'bg-brand-500/15 text-brand-300 border-brand-500/30'
              : 'bg-slate-800/50 text-slate-400 border-slate-700/50 hover:text-slate-200'
          }`}
        >
          <Archive className="size-3.5" />
          <T>المؤرشفة</T>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {filterTabs.map((tab) => (
          <motion.button
            key={tab.key}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setStatusFilter(tab.key)}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all duration-200 ${
              statusFilter === tab.key
                ? 'from-brand-600 to-brand-700 text-white shadow-lg shadow-brand-900/30'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white border border-slate-700/50'
            }`}
          >
            <T>{tab.label}</T>
            <span className="mr-2 text-xs opacity-70">({formatInteger(tab.count, locale)})</span>
          </motion.button>
        ))}
      </div>

      {/* Subtle background-revalidation state (§32) */}
      <DataFreshnessIndicator revalidating={revalidating} />

      {/* Loading */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-20 rounded-lg bg-slate-800" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="border-slate-700/50 bg-slate-800/50">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Banknote className="size-12 text-slate-600 mb-4" />
            <p className="text-slate-400 text-lg font-medium"><T>لا توجد خصومات</T></p>
            <p className="text-slate-500 text-sm mt-1">
              {/* §10: the active period is NAMED in the empty state. */}
              {monthFilter !== 'all'
                ? <><T>لا توجد خصومات مسجلة في </T>{formatMonthKey(monthFilter, locale)}<T>.</T></>
                : <T>ابدأ بإضافة خصم جديد</T>}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Pending Deductions */}
          {pending.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h2 className="text-lg font-semibold text-amber-400 mb-3 flex items-center gap-2">
                <Clock className="size-5" />
                <T>الخصومات المعلقة (</T>{formatInteger(pending.length, locale)}<T>)</T>
              </h2>
              <div className="space-y-3 max-h-96 overflow-y-auto custom-scrollbar">
                <AnimatePresence>
                  {pending.map((ded) => (
                    <motion.div
                      key={ded.id}
                      data-record-id={ded.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="rounded-xl border border-amber-500/20 bg-slate-800/50 p-4 hover:bg-slate-800/80 transition-all"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2 flex-wrap">
                            <EmployeeLink employeeId={ded.employeeId} name={ded.employeeName} compact />
                            <Badge className="bg-slate-600/40 text-slate-300 border-slate-500/30"><T>{ded.type}</T></Badge>
                            <span className="text-brand-400 font-semibold text-sm" dir="ltr">
                              {formatNumber(ded.amount, { locale })} {getUnitLabel(ded.unit)}
                            </span>
                            <span className="text-slate-500 text-sm">{formatMonthKey(ded.month, locale)}</span>
                            {ded.deductionDate && (
                              <span className="text-slate-500 text-xs" dir="ltr">({ded.deductionDate})</span>
                            )}
                          </div>
                          <p className="text-slate-400 text-sm">{ded.reason}</p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          {/* §EVIDENCE-ITEMS — count chip opening the item list. */}
                          <EvidenceSummaryButton items={normalizeEvidenceItems(ded, 'none')} />
                          {canUpdate && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => openEditDialog(ded)}
                              className="border-slate-600 text-slate-300 hover:bg-slate-700"
                            >
                              <Pencil className="size-3.5" />
                              <T>تعديل</T>
                            </Button>
                          )}
                          {canApprove && (
                            <>
                              <Button
                                size="sm"
                                onClick={() => handleReview(ded.id, 'approved')}
                                disabled={reviewing}
                                className="bg-green-600 hover:bg-green-700 text-white"
                              >
                                <Check className="size-3.5" />
                                <T>قبول</T>
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleReview(ded.id, 'rejected')}
                                disabled={reviewing}
                                className="border-red-500/30 text-red-400 hover:bg-red-500/10"
                              >
                                <X className="size-3.5" />
                                <T>رفض</T>
                              </Button>
                            </>
                          )}
                          {/* §2 — SmartActionMenu (primary decision buttons stay visible);
                              delete requires confirmation (§20) */}
                          {canDelete && (
                            <SmartActionMenu
                              actions={[
                                { key: 'archive', label: (ded as any).archived ? translateUIText('استعادة من الأرشيف', locale) : translateUIText('أرشفة', locale), icon: <Archive className="size-3.5" />, onSelect: () => ((ded as any).archived ? void handleArchive(ded.id, false) : setArchivingId(ded.id)), hidden: !canUpdate },
                                { key: 'delete', label: translateUIText('حذف', locale), icon: <Trash2 className="size-3.5" />, destructive: true, onSelect: () => setDeletingId(ded.id) },
                              ]}
                            />
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </motion.div>
          )}

          {/* Approved / Rejected Table */}
          {other.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="rounded-xl border border-slate-700/50 bg-slate-800/50 overflow-hidden"
            >
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-700 hover:bg-transparent">
                      <TableHead className="text-slate-400 text-sm font-medium"><T>الموظف</T></TableHead>
                      <TableHead className="text-slate-400 text-sm font-medium"><T>النوع</T></TableHead>
                      <TableHead className="text-slate-400 text-sm font-medium"><T>المبلغ</T></TableHead>
                      <TableHead className="text-slate-400 text-sm font-medium"><T>الشهر</T></TableHead>
                      <TableHead className="text-slate-400 text-sm font-medium"><T>تاريخ الخصم</T></TableHead>
                      <TableHead className="text-slate-400 text-sm font-medium"><T>السبب</T></TableHead>
                      <TableHead className="text-slate-400 text-sm font-medium"><T>الحالة</T></TableHead>
                      {(canUpdate || canDelete) && (
                        <TableHead className="text-slate-400 text-sm font-medium"><T>إجراءات</T></TableHead>
                      )}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {other.map((ded) => (
                      <TableRow
                        key={ded.id}
                        data-record-id={ded.id}
                        className="border-slate-700/50 hover:bg-slate-700/30"
                      >
                        <TableCell>
                          <EmployeeLink employeeId={ded.employeeId} name={ded.employeeName} compact />
                        </TableCell>
                        <TableCell className="text-slate-300"><T>{ded.type}</T></TableCell>
                        <TableCell className="text-slate-300" dir="ltr">
                          {formatNumber(ded.amount, { locale })} {getUnitLabel(ded.unit)}
                        </TableCell>
                        <TableCell className="text-slate-300">
                          {formatMonthKey(ded.month, locale)}
                        </TableCell>
                        <TableCell className="text-slate-300" dir="ltr">
                          {ded.deductionDate || '—'}
                        </TableCell>
                        <TableCell className="text-slate-400 text-sm max-w-xs truncate">{ded.reason}</TableCell>
                        <TableCell>{getStatusBadge(ded.status)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            {/* ═══ CAPA Integration (Bidirectional) ═══ */}
                            {(ded as any).relatedCapaId && (
                              <div onClick={(e) => e.stopPropagation()}>
                                <CAPALinkBadge capaId={(ded as any).relatedCapaId} compact />
                              </div>
                            )}
                            {/* §20 — ALL row actions live inside the ONE
                                SmartActionMenu; the duplicate external CAPA
                                button was removed. Delete now requires the
                                unified ConfirmDialog (no accidental deletes). */}
                            <SmartActionMenu
                              actions={[
                                { key: 'capa', label: translateUIText('إنشاء CAPA من هذه المخالفة', locale), icon: <ShieldAlert className="size-3.5" />, onSelect: () => requestAnimationFrame(() => { document.getElementById('hr-inline-capa')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }), hidden: !(canCreateCapa && !(ded as any).relatedCapaId && ded.status === 'approved') },
                                { key: 'edit', label: translateUIText('تعديل', locale), icon: <Pencil className="size-3.5" />, onSelect: () => openEditDialog(ded), hidden: !canUpdate },
                                { key: 'archive', label: (ded as any).archived ? translateUIText('استعادة من الأرشيف', locale) : translateUIText('أرشفة', locale), icon: <Archive className="size-3.5" />, onSelect: () => ((ded as any).archived ? void handleArchive(ded.id, false) : setArchivingId(ded.id)), hidden: !canUpdate },
                                { key: 'delete', label: translateUIText('حذف', locale), icon: <Trash2 className="size-3.5" />, destructive: true, onSelect: () => setDeletingId(ded.id), hidden: !canDelete },
                              ]}
                            />
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </motion.div>
          )}
      </div>
      )}

      {/* §ARCHIVE — archive confirmation (not destructive: history kept) */}
      <ConfirmDialog
        open={!!archivingId}
        onOpenChange={(o) => { if (!o) setArchivingId(null); }}
        title={translateUIText('أرشفة الخصم', locale)}
        description={translateUIText('الخصم المؤرشف يصبح سجلاً تاريخياً: لن يحسب في الإجماليات النشطة أو مؤشرات KPI الحالية، ويبقى قابلاً للتدقيق في الأرشيف.', locale)}
        confirmLabel={translateUIText('أرشفة', locale)}
        destructive={false}
        loading={archiveLoading}
        onConfirm={async () => { if (archivingId) await handleArchive(archivingId, true); }}
      />

      {/* §20 — delete REQUIRES confirmation (no accidental deletes) */}
      <ConfirmDialog
        open={!!deletingId}
        onOpenChange={(o) => { if (!o) setDeletingId(null); }}
        description={translateUIText('سيتم حذف خصم الموارد البشرية نهائياً من النظام.', locale)}
        loading={deleteLoading}
        onConfirm={async () => { if (deletingId) await handleDelete(deletingId); }}
      />

      {/* ━━━ §12 INLINE CAPA FORM — opens here (prefilled from the
          approved HR violation) instead of navigating to the CAPA page. ━━━ */}
      <AnimatePresence>
        {canCreateCapa && capaPrefill && (
          <InlineFormPanel
            id="hr-inline-capa"
            tone="violet"
            icon={<ShieldAlert className="size-3.5 text-brand-400" />}
            title={translateUIText('إنشاء CAPA من مخالفة HR', locale)}
            onClose={() => setCapaPrefill(null)}
          >
            <CAPAInlineForm
              key={JSON.stringify(capaPrefill)}
              onClose={() => setCapaPrefill(null)}
              onCreated={() => {
                setCapaPrefill(null);
                void refreshData();
              }}
              employees={employees}
              systemUsers={systemUsers}
              defaultValues={capaPrefill}
            />
          </InlineFormPanel>
        )}
      </AnimatePresence>

      {/* Add Dialog */}
      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent className="backdrop-blur-xl bg-slate-900 border-slate-700 max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-white"><T>إضافة خصم جديد</T></DialogTitle>
            <DialogDescription className="text-slate-400"><T>أدخل تفاصيل الخصم</T></DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <EmployeeSearchInput
                employees={employees}
                value={addForm.employeeId}
                onChange={(id) => setAddForm((p) => ({ ...p, employeeId: id }))}
                label={translateUIText('الموظف', locale)}
                placeholder={translateUIText('ابحث عن اسم الموظف...', locale)}
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300"><T>نوع الخصم</T></Label>
              <Select
                value={addForm.type}
                onValueChange={(v) => setAddForm((p) => ({ ...p, type: v }))}
              >
                <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DEDUCTION_TYPES.map((dt) => (
                    <SelectItem key={dt.value} value={dt.value} className="text-white">
                      <T>{dt.label}</T>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300"><T>الوحدة</T></Label>
              <Select
                value={addForm.unit}
                onValueChange={(v) => setAddForm((p) => ({ ...p, unit: v as 'days' | 'EGP' }))}
              >
                <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="days" className="text-white"><T>أيام</T></SelectItem>
                  <SelectItem value="EGP" className="text-white"><T>جنيه</T></SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300"><T>المبلغ / العدد</T></Label>
              <Input
                type="number"
                min="0"
                step="any"
                value={addForm.amount}
                onChange={(e) => setAddForm((p) => ({ ...p, amount: e.target.value }))}
                className="bg-slate-800 border-slate-600 text-white"
                placeholder="0"
                dir="ltr"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300"><T>الشهر</T></Label>
              <Select
                value={addForm.month}
                onValueChange={(v) => setAddForm((p) => ({ ...p, month: v }))}
              >
                <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                  <SelectValue placeholder={translateUIText('اختر الشهر', locale)} />
                </SelectTrigger>
                <SelectContent>
                  {MONTH_OPTIONS.map((m) => (
                    <SelectItem key={m.value} value={m.value} className="text-white">
                      {formatMonthKey(m.value, locale)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label className="text-slate-300"><T>تاريخ الخصم</T></Label>
              <Input
                value={addForm.deductionDate}
                onChange={(e) => setAddForm((p) => ({ ...p, deductionDate: e.target.value }))}
                className="bg-slate-800 border-slate-600 text-white"
                placeholder="DD/MM/YYYY"
                dir="ltr"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label className="text-slate-300"><T>السبب</T></Label>
              <Textarea
                value={addForm.reason}
                onChange={(e) => setAddForm((p) => ({ ...p, reason: e.target.value }))}
                className="bg-slate-800 border-slate-600 text-white"
                placeholder={translateUIText('اكتب سبب الخصم...', locale)}
                required
              />
            </div>
            <div className="sm:col-span-2">
              {/* §EVIDENCE-ITEMS — unified multi-item evidence collection */}
              <EvidenceCollectionInput
                moduleKey="hrDeductions"
                items={addForm.evidenceItems}
                onChange={(items) => setAddForm((p) => ({ ...p, evidenceItems: items }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAddOpen(false)}
              className="border-slate-600 text-slate-300"
            >
              <T>إلغاء</T>
            </Button>
            <Button
              onClick={handleAdd}
              disabled={saving || !addForm.employeeId || !addForm.amount || !addForm.month || !addForm.reason}
              className="bg-linear-to-r from-brand-600 to-brand-700 hover:from-brand-700 hover:to-brand-800 text-white h-9 px-5 shadow-lg shadow-brand-500/20 transition-all"
            >
              {saving ? <T>جاري الحفظ...</T> : <T>إضافة</T>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="backdrop-blur-xl bg-slate-900 border-slate-700 max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-white"><T>تعديل الخصم</T></DialogTitle>
            <DialogDescription className="text-slate-400"><T>قم بتعديل تفاصيل الخصم</T></DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-slate-300"><T>نوع الخصم</T></Label>
              <Select
                value={editForm.type}
                onValueChange={(v) => setEditForm((p) => ({ ...p, type: v }))}
              >
                <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DEDUCTION_TYPES.map((dt) => (
                    <SelectItem key={dt.value} value={dt.value} className="text-white">
                      <T>{dt.label}</T>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300"><T>الوحدة</T></Label>
              <Select
                value={editForm.unit}
                onValueChange={(v) => setEditForm((p) => ({ ...p, unit: v as 'days' | 'EGP' }))}
              >
                <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="days" className="text-white"><T>أيام</T></SelectItem>
                  <SelectItem value="EGP" className="text-white"><T>جنيه</T></SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300"><T>المبلغ / العدد</T></Label>
              <Input
                type="number"
                min="0"
                step="any"
                value={editForm.amount}
                onChange={(e) => setEditForm((p) => ({ ...p, amount: e.target.value }))}
                className="bg-slate-800 border-slate-600 text-white"
                placeholder="0"
                dir="ltr"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300"><T>الشهر</T></Label>
              <Select
                value={editForm.month}
                onValueChange={(v) => setEditForm((p) => ({ ...p, month: v }))}
              >
                <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                  <SelectValue placeholder={translateUIText('اختر الشهر', locale)} />
                </SelectTrigger>
                <SelectContent>
                  {MONTH_OPTIONS.map((m) => (
                    <SelectItem key={m.value} value={m.value} className="text-white">
                      {formatMonthKey(m.value, locale)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label className="text-slate-300"><T>تاريخ الخصم</T></Label>
              <Input
                value={editForm.deductionDate}
                onChange={(e) => setEditForm((p) => ({ ...p, deductionDate: e.target.value }))}
                className="bg-slate-800 border-slate-600 text-white"
                placeholder="DD/MM/YYYY"
                dir="ltr"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label className="text-slate-300"><T>السبب</T></Label>
              <Textarea
                value={editForm.reason}
                onChange={(e) => setEditForm((p) => ({ ...p, reason: e.target.value }))}
                className="bg-slate-800 border-slate-600 text-white"
                placeholder={translateUIText('اكتب سبب الخصم...', locale)}
                required
              />
            </div>
            <div className="sm:col-span-2">
              {/* §EVIDENCE-ITEMS — unified multi-item evidence collection */}
              <EvidenceCollectionInput
                moduleKey="hrDeductions"
                items={editForm.evidenceItems}
                onChange={(items) => setEditForm((p) => ({ ...p, evidenceItems: items }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditOpen(false)}
              className="border-slate-600 text-slate-300"
            >
              <T>إلغاء</T>
            </Button>
            <Button
              onClick={handleEdit}
              disabled={saving || !editForm.amount || !editForm.reason}
              className="bg-linear-to-r from-brand-600 to-brand-700 hover:from-brand-700 hover:to-brand-800 text-white h-9 px-5 shadow-lg shadow-brand-500/20 transition-all"
            >
              {saving ? <T>جاري الحفظ...</T> : <T>حفظ التعديلات</T>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
