import { NextResponse } from 'next/server';
import ExcelJS from 'exceljs';
import { verifyPermission } from '@/lib/verify-permission';
import { asScopeViewer, filterRowsByEmployeeScope, resolveEmployeeScopeFromDb } from '@/lib/scope/server';
import { formatDate as sharedFormatDate } from '@/lib/i18n/format';
import type { Locale } from '@/lib/i18n/dictionary';

// ════════════════════════════════════════════════════
//  Bilingual UI labels for THIS route's own literal
//  strings (captions, headers, notes). Data values
//  (names, codes, figures) are never translated here.
// ════════════════════════════════════════════════════
const LABELS = {
  ar: {
    sheetTitle: 'تقرير الخصومات الشهري',
    month: 'الشهر',
    workingDays: 'عدد أيام العمل',
    dayUnit: 'يوم',
    employees: 'عدد الموظفين',
    exportDate: 'تاريخ التصدير',
    attendanceSection: 'بيانات الحضور',
    deductionsSection: 'الخصومات',
    total: 'الإجمالي',
    footerNote: 'ملاحظة: كل موظف يحصل على 4 أيام إعفاء تلقائي شهرياً من الخصومات. الأيام الغائبة الأقل من 4 تُحسب كمكافأة حضور.',
    headers: ['م', 'اسم الموظف', 'القسم', 'المسمى الوظيفي', 'أيام الحضور', 'أيام التأخير', 'دقائق التأخير', 'أيام الغياب', 'أيام الإعفاء', 'إجمالي الإعفاء التلقائي', 'أيام المكافأة', 'نسبة الالتزام', 'خصم التأخير', 'خصم الغياب', 'خصم الحضور الكلي', 'خصم الجودة', 'مبلغ الجودة', 'إجمالي الخصم'],
  },
  en: {
    sheetTitle: 'Monthly Deductions Report',
    month: 'Month',
    workingDays: 'Working days',
    dayUnit: 'days',
    employees: 'Employees',
    exportDate: 'Export date',
    attendanceSection: 'Attendance Data',
    deductionsSection: 'Deductions',
    total: 'Total',
    footerNote: 'Note: every employee receives 4 automatic exemption days per month from deductions. Absent days below 4 count as an attendance bonus.',
    headers: ['#', 'Employee Name', 'Department', 'Job Title', 'Present Days', 'Late Days', 'Late Minutes', 'Absent Days', 'Exempt Days', 'Total Auto Exemption', 'Bonus Days', 'Compliance %', 'Late Deduction', 'Absence Deduction', 'Total Attendance Deduction', 'Quality Days', 'Quality Amount', 'Total Deduction'],
  },
} as const;

export async function POST(request: Request) {
  try {
    // Verify permission: reports page - export action required
    const permCheck = await verifyPermission(request, 'reports', 'export');
    if (!permCheck.allowed) {
      return NextResponse.json({ error: permCheck.error }, { status: 403 });
    }

    const body = await request.json();
    const { month, data: postedData, meta, lang: rawLang } = body;
    const lang: Locale = rawLang === 'en' ? 'en' : 'ar';
    type LabelKey = keyof typeof LABELS.ar;
    const L = (key: LabelKey): string => LABELS[lang][key] as string;
    const LList = (key: LabelKey): readonly string[] => LABELS[lang][key] as readonly string[];

    if (!postedData || !Array.isArray(postedData)) {
      return NextResponse.json({ error: 'No data provided' }, { status: 400 });
    }

    // ── READ SCOPE (M0.5) ──
    // An exported file is a list response: the SERVER, not the client,
    // decides which employees may appear. The posted rows are
    // intersected with the caller's authorized employee scope (rows
    // without a resolvable employeeId are dropped fail-closed), and
    // every total in the file is recomputed from the surviving rows —
    // client-posted summary figures are never trusted.
    const scopeCtx = await resolveEmployeeScopeFromDb(
      asScopeViewer(permCheck.user!),
      undefined,
      permCheck.user!.permissions,
    );
    const data = filterRowsByEmployeeScope(
      postedData as Array<Record<string, unknown> & { employeeId?: string | null }>,
      scopeCtx,
    );

    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Qnalys';
    workbook.created = new Date();

    const sheet = workbook.addWorksheet(L('sheetTitle'), {
      properties: { tabColor: { argb: '1F4E79' } },
      views: [{ state: 'frozen', ySplit: 7 }],
    });

    // ── Page Setup ──
    sheet.pageSetup = {
      orientation: 'landscape',
      paperSize: 9, // A4
      fitToPage: true,
      fitToWidth: 1,
      fitToHeight: 0,
      margins: { left: 0.4, right: 0.4, top: 0.5, bottom: 0.5, header: 0.3, footer: 0.3 },
    };

    // ════════════════════════════════════════════════════
    // ROW 1: Title Banner
    // ════════════════════════════════════════════════════
    sheet.mergeCells('A1:R1');
    const titleCell = sheet.getCell('A1');
    titleCell.value = L('sheetTitle');
    titleCell.font = { name: 'Arial', size: 18, bold: true, color: { argb: 'FFFFFF' } };
    titleCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '1F4E79' } };
    titleCell.alignment = { horizontal: 'center', vertical: 'middle' };
    sheet.getRow(1).height = 40;

    // ════════════════════════════════════════════════════
    // ROW 2: Sub-info
    // ════════════════════════════════════════════════════
    sheet.mergeCells('A2:D2');
    const monthCell = sheet.getCell('A2');
    monthCell.value = `${L('month')}: ${month || ''}`;
    monthCell.font = { name: 'Arial', size: 11, bold: true, color: { argb: '1F4E79' } };
    monthCell.alignment = { horizontal: 'right', vertical: 'middle', indent: 1 };

    sheet.mergeCells('E2:J2');
    const daysCell = sheet.getCell('E2');
    daysCell.value = `${L('workingDays')}: ${meta?.monthWorkingDays || ''} ${L('dayUnit')}`;
    daysCell.font = { name: 'Arial', size: 11, bold: true, color: { argb: '1F4E79' } };
    daysCell.alignment = { horizontal: 'center', vertical: 'middle' };

    sheet.mergeCells('K2:N2');
    const empCountCell = sheet.getCell('K2');
    empCountCell.value = `${L('employees')}: ${data.length}`;
    empCountCell.font = { name: 'Arial', size: 11, bold: true, color: { argb: '1F4E79' } };
    empCountCell.alignment = { horizontal: 'center', vertical: 'middle' };

    sheet.mergeCells('O2:R2');
    const dateCell = sheet.getCell('O2');
    const today = new Date();
    dateCell.value = `${L('exportDate')}: ${sharedFormatDate(today, lang)}`;
    dateCell.font = { name: 'Arial', size: 11, bold: true, color: { argb: '1F4E79' } };
    dateCell.alignment = { horizontal: 'right', vertical: 'middle', indent: 1 };

    sheet.getRow(2).height = 25;

    // ════════════════════════════════════════════════════
    // ROW 3: Empty spacing
    // ════════════════════════════════════════════════════
    sheet.getRow(3).height = 8;

    // ════════════════════════════════════════════════════
    // ROW 4: Section Header - Attendance Info
    // ════════════════════════════════════════════════════
    sheet.mergeCells('A4:J4');
    const section1 = sheet.getCell('A4');
    section1.value = L('attendanceSection');
    section1.font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFF' } };
    section1.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '2E75B6' } };
    section1.alignment = { horizontal: 'center', vertical: 'middle' };

    sheet.mergeCells('K4:R4');
    const section2 = sheet.getCell('K4');
    section2.value = L('deductionsSection');
    section2.font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFF' } };
    section2.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'C00000' } };
    section2.alignment = { horizontal: 'center', vertical: 'middle' };

    sheet.getRow(4).height = 22;

    // ════════════════════════════════════════════════════
    // ROW 5: Column Headers
    // ════════════════════════════════════════════════════
    const headerWidths = [5, 28, 16, 18, 12, 12, 14, 12, 12, 16, 12, 14, 12, 12, 14, 12, 14, 14];
    const headers = LList('headers').map((text, idx) => ({ text, width: headerWidths[idx] }));

    const headerRow = sheet.getRow(5);
    headerRow.height = 28;

    headers.forEach((h, idx) => {
      const cell = headerRow.getCell(idx + 1);
      cell.value = h.text;
      cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FFFFFF' } };

      // Section colors: blue for attendance, red for deductions
      if (idx <= 9) {
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '4472C4' } };
      } else {
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'E0604040' } };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'C0504D' } };
      }

      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      cell.border = {
        top: { style: 'thin', color: { argb: 'FFFFFF' } },
        bottom: { style: 'thin', color: { argb: 'FFFFFF' } },
        left: { style: 'thin', color: { argb: 'D9D9D9' } },
        right: { style: 'thin', color: { argb: 'D9D9D9' } },
      };
    });

    // ════════════════════════════════════════════════════
    // ROW 6: Thin separator
    // ════════════════════════════════════════════════════
    sheet.getRow(6).height = 4;

    // ════════════════════════════════════════════════════
    // DATA ROWS (starting from row 7)
    // ════════════════════════════════════════════════════
    data.forEach((row: Record<string, unknown>, rowIdx: number) => {
      const rowNum = rowIdx + 7;
      const dataRow = sheet.getRow(rowNum);
      dataRow.height = 22;

      const values = [
        rowIdx + 1,
        row.employeeName || '',
        row.department || '',
        row.position || '',
        row.totalPresent || 0,
        row.totalLate || 0,
        row.totalMinutesLateFormatted || (row.totalMinutesLate || 0),
        row.totalAbsent || 0,
        row.totalExempt || 0,
        row.autoExemptDays || 0,
        row.bonusDays || 0,
        row.attendanceCompliance || 0,
        row.lateDeductionDays || 0,
        row.absenceDeductionDays || 0,
        row.totalAttendanceDeductionDays || 0,
        row.totalQualityDays || 0,
        row.totalQualityAmount || 0,
        row.totalDeductionDays || 0,
      ];

      const isEven = rowIdx % 2 === 0;
      const bgColor = isEven ? 'F2F7FB' : 'FFFFFF';

      values.forEach((val, colIdx: number) => {
        const cell = dataRow.getCell(colIdx + 1);
        cell.value = val as ExcelJS.CellValue;

        // Styling
        cell.font = {
          name: 'Arial',
          size: 10,
          bold: colIdx === 0,
          color: { argb: '333333' },
        };
        cell.alignment = {
          horizontal: colIdx <= 3 ? 'right' : 'center',
          vertical: 'middle',
          indent: colIdx <= 3 ? 1 : 0,
        };

        // Alternating row background
        if (!isEven) {
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: bgColor } };
        }

        // Borders
        cell.border = {
          top: { style: 'hair', color: { argb: 'D0D0D0' } },
          bottom: { style: 'hair', color: { argb: 'D0D0D0' } },
          left: { style: 'hair', color: { argb: 'D0D0D0' } },
          right: { style: 'hair', color: { argb: 'D0D0D0' } },
        };

        // ── Conditional colors ──
        // Compliance: green >= 90, amber >= 75, red < 75
        if (colIdx === 11) {
          const num = Number(val) || 0;
          if (num >= 90) {
            cell.font = { ...cell.font, color: { argb: '006100' }, bold: true };
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'C6EFCE' } };
          } else if (num >= 75) {
            cell.font = { ...cell.font, color: { argb: '9C6500' }, bold: true };
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEB9C' } };
          } else {
            cell.font = { ...cell.font, color: { argb: '9C0006' }, bold: true };
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFC7CE' } };
          }
        }

        // Deduction columns: red if > 0
        if (colIdx === 17 && Number(val) > 0) {
          cell.font = { ...cell.font, color: { argb: 'C00000' }, bold: true };
        }

        // Bonus days: green if > 0
        if (colIdx === 10 && Number(val) > 0) {
          cell.font = { ...cell.font, color: { argb: '006100' }, bold: true };
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'E2EFDA' } };
        }
      });
    });

    // ════════════════════════════════════════════════════
    // SUMMARY ROW
    // ════════════════════════════════════════════════════
    const summaryStartRow = data.length + 7;
    const summaryRow = sheet.getRow(summaryStartRow);
    summaryRow.height = 28;

    // Merge label
    sheet.mergeCells(`A${summaryStartRow}:D${summaryStartRow}`);
    const sumLabel = summaryRow.getCell(1);
    sumLabel.value = L('total');
    sumLabel.font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFF' } };
    sumLabel.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '1F4E79' } };
    sumLabel.alignment = { horizontal: 'center', vertical: 'middle' };

    // Summary totals are recomputed from the SCOPE-FILTERED rows above
    // (M0.5) — the posted summary object is intentionally ignored.
    const summaryValues = [
      (data.reduce((s: number, r: any) => s + (r.totalPresent || 0), 0)),
      (data.reduce((s: number, r: any) => s + (r.totalLate || 0), 0)),
      (data.reduce((s: number, r: any) => s + (r.totalMinutesLate || 0), 0)),
      (data.reduce((s: number, r: any) => s + (r.totalAbsent || 0), 0)),
      (data.reduce((s: number, r: any) => s + (r.totalExempt || 0), 0)),
      (data.reduce((s: number, r: any) => s + (r.autoExemptDays || 0), 0)),
      (data.reduce((s: number, r: any) => s + (r.bonusDays || 0), 0)),
      (data.length > 0 ? Math.round(data.reduce((s: number, r: any) => s + (r.attendanceCompliance || 0), 0) / data.length) : 0),
      (data.reduce((s: number, r: any) => s + (r.lateDeductionDays || 0), 0)),
      (data.reduce((s: number, r: any) => s + (r.absenceDeductionDays || 0), 0)),
      (data.reduce((s: number, r: any) => s + (r.totalAttendanceDeductionDays || 0), 0)),
      (data.reduce((s: number, r: any) => s + (r.totalQualityDays || 0), 0)),
      (data.reduce((s: number, r: any) => s + (r.totalQualityAmount || 0), 0)),
      (data.reduce((s: number, r: any) => s + (r.totalDeductionDays || 0), 0)),
    ];

    summaryValues.forEach((val: number, idx: number) => {
      const cell = summaryRow.getCell(idx + 5);
      cell.value = idx === 7 ? `${val}%` : val;
      cell.font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFF' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '1F4E79' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.border = {
        top: { style: 'thin', color: { argb: '1F4E79' } },
        bottom: { style: 'medium', color: { argb: '1F4E79' } },
        left: { style: 'thin', color: { argb: 'D0D0D0' } },
        right: { style: 'thin', color: { argb: 'D0D0D0' } },
      };
      // Round numbers
      if (typeof val === 'number') {
        cell.value = Math.round(val * 100) / 100;
      }
    });

    // ════════════════════════════════════════════════════
    // FOOTER: Free days policy note
    // ════════════════════════════════════════════════════
    const footerRow = summaryStartRow + 2;
    sheet.mergeCells(`A${footerRow}:R${footerRow}`);
    const footerCell = sheet.getCell(`A${footerRow}`);
    footerCell.value = L('footerNote');
    footerCell.font = { name: 'Arial', size: 9, italic: true, color: { argb: '666666' } };
    footerCell.alignment = { horizontal: 'center', vertical: 'middle' };

    // ════════════════════════════════════════════════════
    // Set Column Widths
    // ════════════════════════════════════════════════════
    headers.forEach((h, idx) => {
      sheet.getColumn(idx + 1).width = h.width;
    });

    // ════════════════════════════════════════════════════
    // Auto-filter on headers
    // ════════════════════════════════════════════════════
    const lastDataCol = String.fromCharCode(64 + headers.length); // R
    sheet.autoFilter = {
      from: { row: 5, column: 1 },
      to: { row: summaryStartRow - 1, column: headers.length },
    };

    // ════════════════════════════════════════════════════
    // Generate buffer
    // ════════════════════════════════════════════════════
    const buffer = await workbook.xlsx.writeBuffer();

    return new NextResponse(buffer, {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename=report_${month || 'unknown'}.xlsx`,
      },
    });
  } catch (error) {
    console.error('Export error:', error);
    return NextResponse.json({ error: 'Failed to export' }, { status: 500 });
  }
}
