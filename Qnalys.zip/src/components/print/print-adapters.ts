// ══════════════════════════════════════════════════════════════
//  Print adapters — map EXISTING report payloads into the generic
//  PrintReportModel. §PRINT (Requirement 7): printing targets exactly
//  these three sections:
//      1. ملخص الجودة            (KpiManagementSummary)
//      2. التقرير الإداري الشامل  (ManagementReport)
//      3. تحليل الأداء            (EmployeePerformanceDataset)
//
//  Adapters are pure projections of data the tabs ALREADY hold —
//  opening the print view never refetches. Missing data is rendered
//  as '—', never fabricated.
// ══════════════════════════════════════════════════════════════

import type { PrintReportModel, PrintSection } from './print-report-store';
import type { EvidenceItem } from '@/types';
import { formatEvidenceItemsAsText } from '@/lib/evidence/presentation';
import { formatNumber, formatPercentage, formatMonthKey, displayLocale } from '@/lib/i18n/format';
import { presentStatus } from '@/lib/i18n/presentation';
import { resolveStoredLabelOrVerbatim } from '@/lib/i18n/dynamic-labels';

const dash = (v: unknown): string =>
  v === null || v === undefined || v === '' ? '—' : String(v);

const num = (v: unknown): string =>
  v === null || v === undefined ? '—' : formatNumber(Number(v));

const pct = (v: unknown): string =>
  v === null || v === undefined ? '—' : formatPercentage(Number(v));

/**
 * §DYNAMIC-LABELS — a stored SEMANTIC label (category name, status,
 * type frozen in a legacy record) resolves to the locale label before
 * printing; anything unknown passes through verbatim (business data).
 */
const storedLabel = (v: unknown): string =>
  typeof v === 'string' ? resolveStoredLabelOrVerbatim(v, displayLocale()) : dash(v);

const monthLabel = (monthKey?: string | null): string => formatMonthKey(monthKey);

// ─────────────────────────────────────────────────────────────
//  §I18N-BOUNDARY — system-generated STATUS labels only.
//  These helpers localize APPLICATION-OWNED enum vocabulary (status /
//  severity / employment / decision SYSTEM labels) at model-build time.
//  They must never be fed user data — names, notes and descriptions
//  bypass them entirely and are rendered exactly as stored.
// ─────────────────────────────────────────────────────────────
const ui = (ar: string, en: string): string => (displayLocale() === 'en' ? en : ar);

// §REPORT-SOURCE — THE one approved report source/provenance footer,
// centralized so every report path renders the identical wording.
// Self-localizes at model-build time (§I18N-BOUNDARY rule for static
// adapter footers); PrintReportDocument renders it raw.
export function reportSourceFooter(): string {
  return ui(
    'المصدر: نظام Qnalys — تم احتساب المؤشرات والبيانات وفقًا للسجلات المعتمدة ضمن الفترة المحددة في التقرير.',
    'Source: Qnalys System — Metrics and data are calculated from approved records within the reporting period.',
  );
}

/** [ar, en] label for a system enum code; unknown codes pass through raw. */
const uiMap = (map: Record<string, [string, string]>, code: string | null | undefined, fallback = '—'): string => {
  if (!code) return fallback;
  const entry = map[code];
  return entry ? (displayLocale() === 'en' ? entry[1] : entry[0]) : fallback;
};

const SEVERITY_LABELS: Record<string, [string, string]> = {
  low: ['منخفضة', 'Low'], medium: ['متوسطة', 'Medium'], high: ['مرتفعة', 'High'], critical: ['حرجة', 'Critical'],
  HIGH: ['مرتفعة', 'High'], MEDIUM: ['متوسطة', 'Medium'], LOW: ['منخفضة', 'Low'],
};

const UNIT_TYPE_LABELS: Record<string, [string, string]> = {
  team: ['فريق', 'Team'],
  department: ['قسم', 'Department'],
  company: ['شركة', 'Company'],
};

// ─────────────────────────────────────────────────────────────
//  1) ملخص الجودة — KpiManagementSummary
// ─────────────────────────────────────────────────────────────

interface KpiSummaryGroupLike {
  key: string;
  label: string;
  employeeCount: number;
  avgRawScore: number | null;
  avgContribution: number | null;
}

interface KpiManagementSummaryLike {
  reportKind?: 'SUMMARY';
  monthKey?: string;
  label?: string;
  statisticsKind?: string;
  counts?: Record<string, number | null>;
  qualityAverages?: {
    avgRawScore?: number | null;
    avgContribution?: number | null;
    highest?: { employeeName?: string; rawScore?: number } | null;
    lowest?: { employeeName?: string; rawScore?: number } | null;
  } | null;
  departments?: KpiSummaryGroupLike[];
  teams?: KpiSummaryGroupLike[];
  generatedAt?: string;
}

function groupSection(heading: string, groups?: KpiSummaryGroupLike[]): PrintSection {
  const rows = (groups ?? []).map((g) => [
    g.label ?? g.key,
    num(g.employeeCount),
    pct(g.avgRawScore),
    num(g.avgContribution),
  ]);
  return {
    heading,
    table: {
      columns: ['المجموعة', 'عدد الموظفين', 'متوسط درجة الجودة', 'متوسط المساهمة'],
      rows,
    },
  };
}

export function qualitySummaryToPrintModel(summary: KpiManagementSummaryLike): PrintReportModel {
  const c = summary.counts ?? {};
  const avg = summary.qualityAverages;
  return {
    title: 'ملخص الجودة',
    subject: summary.label || 'إحصائيات جودة KPI',
    period: monthLabel(summary.monthKey),
    generatedAt: summary.generatedAt,
    stats: [
      { label: 'الموظفون المؤهلون', value: num(c.eligible) },
      { label: 'KPI متاح', value: num(c.available) },
      { label: 'معلق', value: num(c.pending) },
      { label: 'غير مكتمل', value: num(c.incomplete) },
      { label: 'صفر', value: num(c.zero) },
      { label: 'مجمّد', value: num(c.finalized) },
      { label: 'متوسط درجة الجودة', value: pct(avg?.avgRawScore) },
      { label: 'متوسط المساهمة', value: num(avg?.avgContribution) },
      { label: 'أعلى درجة', value: avg?.highest ? `${avg.highest.employeeName ?? '—'} (${num(avg.highest.rawScore)}%)` : '—' },
      { label: 'أدنى درجة', value: avg?.lowest ? `${avg.lowest.employeeName ?? '—'} (${num(avg.lowest.rawScore)}%)` : '—' },
    ],
    sections: [
      groupSection('الأداء حسب القسم', summary.departments),
      groupSection('الأداء حسب الفريق', summary.teams),
    ],
    footerNote: ui(
      'إحصائيات جودة KPI (ليست إحصائيات KPI على مستوى الشركة) — مصدر البيانات: محرك الجودة.',
      'Quality KPI statistics (never company-level KPI statistics) — data source: the quality engine.',
    ),
  };
}

// ─────────────────────────────────────────────────────────────
//  2) التقرير الإداري الشامل — ManagementReport
// ─────────────────────────────────────────────────────────────

interface DomainFactsLike {
  label?: string;
  total?: number;
  open?: number;
  closed?: number;
}

interface DepartmentRowLike {
  key?: string;
  label?: string;
  employeeCount?: number;
  quality?: { avgRawScore?: number | null; avgContribution?: number | null } | null;
  domains?: Record<string, DomainFactsLike>;
}

interface ManagementReportLike {
  monthKey?: string;
  explanation?: string;
  generatedAt?: string;
  qualitySummary?: KpiManagementSummaryLike | null;
  departments?: DepartmentRowLike[];
  teams?: DepartmentRowLike[];
  totals?: { domains?: Record<string, DomainFactsLike> };
  activeEmployeeCount?: number;
}

const DOMAIN_ORDER = ['complaints', 'capaCases', 'followUps', 'hrDeductions'] as const;
const DOMAIN_LABELS: Record<string, [string, string]> = {
  complaints: ['الشكاوى', 'Complaints'],
  capaCases: ['كابا', 'CAPA'],
  followUps: ['المتابعات', 'Follow-ups'],
  hrDeductions: ['خصومات الموارد البشرية', 'HR Deductions'],
};
const domainLabel = (k: string): string => (DOMAIN_LABELS[k] ? (displayLocale() === 'en' ? DOMAIN_LABELS[k][1] : DOMAIN_LABELS[k][0]) : k);

function deptTable(rows?: DepartmentRowLike[]): PrintSection {
  const tableRows = (rows ?? []).map((r) => {
    const domains = r.domains ?? {};
    return [
      r.label ?? '—',
      num(r.employeeCount),
      pct(r.quality?.avgRawScore),
      num(r.quality?.avgContribution),
      ...DOMAIN_ORDER.map((k) => num(domains[k]?.total ?? 0)),
      ...DOMAIN_ORDER.map((k) => num(domains[k]?.open ?? 0)),
    ];
  });
  return {
    heading: 'الإدارات والفرق',
    table: {
      columns: [
        'المجموعة', 'الموظفون', 'متوسط درجة الجودة', 'متوسط المساهمة',
        ...DOMAIN_ORDER.map((k) => `${domainLabel(k)} ${ui('(إجمالي)', '(total)')}`),
        ...DOMAIN_ORDER.map((k) => `${domainLabel(k)} ${ui('(مفتوح)', '(open)')}`),
      ],
      rows: tableRows,
      ltrColumns: [],
    },
  };
}

export function managementReportToPrintModel(report: ManagementReportLike): PrintReportModel {
  const totals = report.totals?.domains ?? {};
  return {
    title: 'التقرير الإداري الشامل',
    subject: 'ملخص إداري مركزي — الجودة والعمليات',
    period: monthLabel(report.monthKey),
    generatedAt: report.generatedAt,
    stats: [
      { label: 'الشهر', value: monthLabel(report.monthKey) || '—' },
      { label: 'موظفون بنشاط مسجل', value: num(report.activeEmployeeCount) },
      ...DOMAIN_ORDER.map((k) => ({
        label: `${domainLabel(k)} ${ui('— إجمالي', '— total')}`,
        value: num(totals[k]?.total ?? 0),
        hint: totals[k] ? `${ui('مفتوح', 'Open')}: ${num(totals[k]?.open ?? 0)}` : undefined,
      })),
    ],
    sections: [
      deptTable(report.departments),
      deptTable(report.teams),
      ...(report.explanation
        ? [{ heading: 'منهجية التقرير', paragraphs: [report.explanation] } satisfies PrintSection]
        : []),
    ],
    footerNote: ui(
      'الكتل الكمية: كتل إدارية بحتة — لا تغيّر أي قاعدة عمل أو نتيجة KPI.',
      'Quantity blocks: purely administrative — no business rule or KPI result changes.',
    ),
  };
}

// ─────────────────────────────────────────────────────────────
//  3) تحليل الأداء — EmployeePerformanceDataset
// ─────────────────────────────────────────────────────────────

interface DeductionRecordLike {
  id?: string;
  date?: string;
  type?: string;
  description?: string;
  deductionDays?: number;
  deductionAmount?: number;
}

interface ObservationRecordLike {
  id?: string;
  observationDate?: string;
  categoryName?: string;
  points?: number;
  isBonus?: boolean;
  approvalStatus?: string;
  notes?: string;
}

/**
 * §PRINT-IDENTITY-PARITY — the employee block mirrors the CANONICAL
 * EmployeeIdentityFacts field names (employeeName / employeeCode / …).
 * It previously invented `name` / `code`, which read undefined off the
 * real dataset and dropped the printed header into the generic scope
 * fallback (النطاق: <department>) — the department/team replacing the
 * employee as the report subject. Canonical names keep live and print
 * on the ONE identity source (no second employee pipeline).
 */
interface EmployeeIdentityFactsLike {
  employeeId?: string;
  employeeName?: string;
  employeeCode?: string | null;
  department?: string | null;
  team?: string | null;
  manager?: string | null;
  position?: string | null;
  employmentStatus?: string | null;
}

interface DatasetLike {
  employee?: EmployeeIdentityFactsLike;
  period?: { monthKey?: string };
  kpi?: {
    weightedTotal?: number | null;
    // §PRINT-IDENTITY-PARITY — canonical KpiQualityFacts field names
    // (weightedContribution, not an invented `contribution`).
    quality?: { rawScore?: number | null; weight?: number | null; weightedContribution?: number | null; status?: string | null } | null;
    overallStatus?: string | null;
    message?: string | null;
  };
  quality?: {
    observations?: {
      total?: number; approved?: number; pending?: number; rejected?: number;
      records?: ObservationRecordLike[];
      /** Deterministic distributions (EmployeePerformanceDataset) — printed as stats when present. */
      bySeverity?: Record<string, number>;
      byResolutionStatus?: Record<string, number>;
      byCategory?: Array<{ categoryId: string | null; categoryName: string; count: number }>;
    };
    deductions?: {
      count?: number; totalDays?: number; totalAmount?: number;
      /** §16 — record reasons NEVER print; only the summary enters the
       *  executive document (details stay in the dedicated view). */
      records?: Array<{ deductionDays?: number; deductionAmount?: number; date?: string }>;
    };
  };
  complaints?: { total?: number; stillOpen?: number; resolvedOrClosed?: number; avgResolutionDays?: number | null };
  capa?: { total?: number; active?: number; overdue?: number; closedCount?: number };
  followUps?: { total?: number; active?: number; overdue?: number; completionRate?: number | null };
  generatedAt?: string;
}

const OBS_STATUS_LABELS: Record<string, [string, string]> = {
  pending: ['قيد الاعتماد', 'Pending'],
  approved: ['معتمدة', 'Approved'],
  rejected: ['مرفوضة', 'Rejected'],
};

// §REPORT-IDENTITY — the live header's employment-status vocabulary
// (view-model EMPLOYMENT_STATUS_LABELS); the print header carries the
// label only for non-active employees, exactly like the screen.
const EMPLOYMENT_STATUS_LABELS: Record<string, [string, string]> = {
  active: ['نشط', 'Active'],
  inactive: ['غير نشط', 'Inactive'],
  archived: ['مؤرشف', 'Archived'],
  unknown: ['غير معروف', 'Unknown'],
};

// §QUALITY-INTELLIGENCE — the localized analytical views computed by
// the smart report page over the SAME payload (no refetch, no
// recomputation) so the printed document carries the identical
// executive summary / KPI breakdown / concentration / narrative /
// attention / data-quality matrix the screen shows.
type IntelligenceViewsLike = import('@/components/pages/quality-kpi/smart-report/intelligence-view').IntelligenceViews;

export function performanceDatasetToPrintModel(
  dataset: DatasetLike,
  options?: { title?: string; intelligence?: IntelligenceViewsLike },
): PrintReportModel {
  const sections: PrintSection[] = [];

  // ── §QUALITY-INTELLIGENCE — the analytical sections come FIRST so
  // the printed document reads as a management intelligence report,
  // not a dashboard dump. Values are the page's own localized views.
  const intel = options?.intelligence;
  if (intel) {
    const exec = intel.executive;
    const execStats: Array<{ label: string; value: string }> = [
      { label: 'مؤشر الأداء (KPI)', value: exec.scoreDisplay },
      // §KPI-INCOMPLETE — an incomplete calculation shows the partial
      // calculated POINTS and the evaluation status, never a percentage
      // that could read as the final KPI.
      ...(exec.calculatedPointsDisplay
        ? [{ label: 'النقاط المحتسبة', value: exec.calculatedPointsDisplay }]
        : []),
      ...(exec.evaluationStatusLabel
        ? [{ label: 'حالة التقييم', value: exec.evaluationStatusLabel }]
        : []),
      { label: 'نقطة مقارنة بالشهر السابق', value: exec.deltaDisplay ?? '—' },
      { label: 'الاتجاه', value: exec.trendLabel ?? '—' },
      { label: 'جودة الفترة', value: exec.qualityScoreDisplay },
      { label: 'المخاطر', value: exec.riskLabel ?? '—' },
      { label: 'حالة القرار', value: exec.decisionStatusLabel ?? '—' },
      // §3 EXECUTIVE HEADER — explicit deal semantics in print too.
      { label: 'تقفيلات الفترة', value: exec.closedDuringPeriodDisplay },
      { label: 'الصفقات الحالية', value: exec.currentDealsDisplay },
    ];
    const execParagraphs: string[] = [];
    // §12 — incompleteMessage already names the missing components; no
    // duplicate paragraph.
    if (exec.incompleteMessage) execParagraphs.push(exec.incompleteMessage);
    sections.push({
      heading: 'الملخص التنفيذي للأداء والجودة',
      stats: execStats,
      paragraphs: execParagraphs.length > 0 ? execParagraphs : undefined,
    });

    // §4 Top 3 signals — the compact management headline.
    if (intel.signals.length > 0) {
      sections.push({
        heading: 'أهم 3 إشارات',
        table: {
          columns: ['الإشارة'],
          rows: intel.signals.map((s, i) => [`${i + 1}. ${s.text}`]),
        },
      });
    }

    // §15 What changed — current vs previous comparable period.
    if (intel.whatChanged.length > 0) {
      sections.push({
        heading: 'ماذا تغير؟ (مقارنة بالشهر المماثل السابق)',
        table: {
          columns: ['المؤشر', 'السابق', 'الحالي', 'التغير'],
          rows: intel.whatChanged.map((r) => [r.metricLabel, r.previousDisplay, r.currentDisplay, r.deltaDisplay]),
        },
      });
    }

    // Full configured KPI component breakdown — percentage business
    // terminology (Defined Rate / Achieved Rate / Calculated Points).
    sections.push({
      heading: 'مكونات التقييم',
      table: {
        columns: ['مكون التقييم', 'النسبة المحددة', 'النسبة المحققة', 'النقاط المحتسبة', 'الحالة'],
        rows: intel.kpi.rows.map((r) => [r.name, r.definedRateDisplay, r.achievedRateDisplay, r.calculatedPointsDisplay, r.statusLabel]),
      },
    });

    // Issue concentration + deterministic patterns.
    if (intel.quality.concentration.length > 0) {
      const concParagraphs: string[] = [];
      if (intel.quality.topIssueLine) concParagraphs.push(intel.quality.topIssueLine);
      if (intel.quality.previousDeltaLine) concParagraphs.push(intel.quality.previousDeltaLine);
      sections.push({
        heading: 'تركّز المشكلات',
        paragraphs: concParagraphs.length > 0 ? concParagraphs : undefined,
        table: {
          columns: ['فئة المشكلة', 'العدد', 'النسبة'],
          rows: intel.quality.concentration.map((c) => [storedLabel(c.categoryName), c.count, c.shareDisplay]),
        },
      });
    }
    if (intel.patterns.length > 0) {
      sections.push({
        heading: 'الأنماط المكتشفة (قواعد حتمية)',
        table: {
          columns: ['النمط'],
          rows: intel.patterns.map((p) => [p.text]),
        },
      });
    }

    // Executive narrative — deterministic sentences over the facts.
    if (intel.narrative.length > 0) {
      sections.push({
        heading: 'التحليل التنفيذي',
        paragraphs: intel.narrative.map((n) => n.text),
      });
    }

    // Management attention — WHAT / WHY / SOURCE.
    if (intel.attention.length > 0) {
      sections.push({
        heading: 'يحتاج انتباه الإدارة',
        table: {
          columns: ['الإشارة', 'التفصيل', 'المصدر'],
          rows: intel.attention.map((a) => [a.what, a.why ?? '—', a.source]),
        },
      });
    }

    // Data-quality availability matrix.
    sections.push({
      heading: 'جودة البيانات وتوافر المصادر',
      table: {
        columns: ['المصدر', 'التوافر'],
        rows: intel.dataQuality.rows.map((r) => [r.sourceLabel, r.availabilityLabel]),
      },
    });
  }

  const observations = dataset.quality?.observations;
  if (observations?.records && observations.records.length > 0) {
    // Deterministic distributions first — the printed report must carry
    // the same analysis the screen shows, not only the raw record list.
    const distroRows: Array<Array<string | number>> = [
      ...Object.entries(observations.bySeverity ?? {}).map(([k, v]) => [ui('الخطورة', 'Severity'), uiMap(SEVERITY_LABELS, k, 'أخرى'), v] as Array<string | number>),
      ...Object.entries(observations.byResolutionStatus ?? {}).map(([k, v]) => [ui('حالة المعالجة', 'Resolution status'), uiMap(SEVERITY_LABELS, k, 'أخرى'), v] as Array<string | number>),
      ...(observations.byCategory ?? []).map((c) => [ui('التصنيف', 'Category'), c.categoryId === '_unclassified' ? ui('غير مصنّف', 'Uncategorized') : storedLabel(c.categoryName), c.count] as Array<string | number>),
    ];
    sections.push({
      heading: 'إحصائيات ملاحظات الجودة',
      stats: [
        { label: 'إجمالي الملاحظات', value: num(observations.total) },
        { label: 'معتمدة', value: num(observations.approved) },
        { label: 'قيد الاعتماد', value: num(observations.pending) },
        { label: 'مرفوضة', value: num(observations.rejected) },
      ],
      table: distroRows.length > 0
        ? { columns: ['البعد', 'القيمة', 'العدد'], rows: distroRows }
        : undefined,
    });
    sections.push({
      heading: 'ملاحظات الجودة',
      table: {
        columns: ['التاريخ', 'التصنيف', 'النقاط', 'الحالة', 'التفاصيل'],
        rows: observations.records.map((o) => [
          dash(o.observationDate),
          storedLabel(o.categoryName),
          o.isBonus ? `+${num(o.points)}` : (o.points ? `−${num(o.points)}` : '—'),
          uiMap(OBS_STATUS_LABELS, o.approvalStatus, dash(o.approvalStatus)),
          dash(o.notes),
        ]),
      },
    });
  }

  // §16 — the executive print carries the deductions SUMMARY only
  // (count / totals / highest single deduction). Free-text reasons and
  // per-record rows stay in the dedicated permission-gated view.
  const deductions = dataset.quality?.deductions;
  if (deductions && (deductions.count ?? 0) > 0) {
    const records = deductions.records ?? [];
    const highest = records.reduce<{ days: number; amount: number; date: string } | null>((acc, r) => {
      const days = r.deductionDays ?? 0;
      const amount = r.deductionAmount ?? 0;
      if (!acc) return { days, amount, date: r.date ?? '—' };
      if (days > acc.days || (days === acc.days && amount > acc.amount)) return { days, amount, date: r.date ?? '—' };
      return acc;
    }, null);
    sections.push({
      heading: 'خصومات الجودة — ملخص الفترة',
      stats: [
        { label: 'عدد الخصومات', value: num(deductions.count) },
        { label: 'إجمالي الأيام', value: num(deductions.totalDays) },
        { label: 'إجمالي المبلغ', value: num(deductions.totalAmount) },
        // §I18N-BOUNDARY — the day/amount UNIT WORDS are system vocabulary.
        { label: 'أعلى خصم منفرد', value: highest ? `${num(highest.days)} ${ui('يوم', 'day(s)')} / ${num(highest.amount)}` : '—' },
      ],
      // §I18N-BOUNDARY — a fixed system sentence, self-localizing.
      paragraphs: [ui(
        'التفاصيل والأسباب تُعرض في تقرير الخصومات المخصص وفق الصلاحيات.',
        'Details and reasons are shown in the dedicated deductions report, per permissions.',
      )],
    });
  }

  const capa = dataset.capa;
  if (capa) {
    sections.push({
      heading: 'خطأ وتصحيح (كابا)',
      stats: [
        { label: 'إجمالي الحالات', value: num(capa.total) },
        { label: 'حالات نشطة', value: num(capa.active) },
        { label: 'متأخرة', value: num(capa.overdue) },
        { label: 'مغلقة', value: num(capa.closedCount) },
      ],
    });
  }

  const followUps = dataset.followUps;
  if (followUps) {
    sections.push({
      heading: 'المتابعات اليومية',
      stats: [
        { label: 'الإجمالي', value: num(followUps.total) },
        { label: 'نشطة', value: num(followUps.active) },
        { label: 'متأخرة', value: num(followUps.overdue) },
        { label: 'نسبة الإنجاز', value: followUps.completionRate == null ? '—' : `${num(followUps.completionRate)}%` },
      ],
    });
  }

  const complaints = dataset.complaints;
  if (complaints) {
    sections.push({
      heading: 'شكاوى العملاء',
      stats: [
        { label: 'الإجمالي', value: num(complaints.total) },
        { label: 'مفتوحة', value: num(complaints.stillOpen) },
        { label: 'محلولة/مغلقة', value: num(complaints.resolvedOrClosed) },
        { label: 'متوسط زمن الحل (يوم)', value: num(complaints.avgResolutionDays) },
      ],
    });
  }

  const quality = dataset.kpi?.quality;
  // §PRINT-IDENTITY-PARITY — the SAME canonical EmployeeIdentityFacts
  // the live header renders. The name is PRIMARY; a genuinely unnamed
  // employee gets the explicit unnamed label (the live header's own
  // fallback) — the team/department NEVER substitutes for the name.
  const employee = dataset.employee;
  // §ORG-SEMANTICS — the department and the TEAM are distinct org-tree
  // levels: when both resolve to the SAME node (an employee directly
  // under a team whose stored department string repeats the team), the
  // department is dropped rather than labeling the team as a department.
  const sameOrgNode = employee?.department != null
    && employee?.team != null
    && employee.department.localeCompare(employee.team, 'ar') === 0;
  const identityDepartment = sameOrgNode ? null : employee?.department ?? null;
  return {
    title: options?.title ?? 'تحليل الأداء',
    subject: [
      employee?.employeeName,
      employee?.employeeCode,
      identityDepartment,
    ].filter(Boolean).join(' — '),
    // §PRINT-HEADER — structured employee identity from authoritative
    // sources (employee record + org tree), never a generic label. The
    // MANAGER is a context fact (§REPORT-IDENTITY — the employee is the
    // subject; the team never replaces the name).
    identity: {
      name: employee?.employeeName || ui('موظف بدون اسم', 'Unnamed employee'),
      code: employee?.employeeCode ?? null,
      position: employee?.position ?? null,
      team: employee?.team ?? null,
      department: identityDepartment,
      manager: employee?.manager ?? null,
      // §REPORT-IDENTITY — surfaced only when it applies (non-active),
      // mirroring the live header's lifecycle badge semantics.
      employmentStatusLabel:
        employee?.employmentStatus && employee.employmentStatus !== 'active'
          ? uiMap(EMPLOYMENT_STATUS_LABELS, employee.employmentStatus, employee.employmentStatus)
          : null,
    },
    period: monthLabel(dataset.period?.monthKey),
    generatedAt: dataset.generatedAt,
    // §TERMINOLOGY — percentage business language, no weight/weighting
    // vocabulary anywhere in the printed document.
    stats: [
      { label: 'نسبة الجودة', value: pct(quality?.rawScore) },
      { label: 'النسبة المحددة للجودة', value: pct(quality?.weight) },
      { label: 'النقاط المحتسبة للجودة', value: num(quality?.weightedContribution) },
      { label: 'إجمالي النسبة المحتسبة', value: num(dataset.kpi?.weightedTotal) },
      { label: 'ملاحظات الجودة', value: num(observations?.total) },
      { label: 'خصومات الجودة (يوم)', value: num(deductions?.totalDays) },
    ],
    sections,
    footerNote: dataset.kpi?.message || reportSourceFooter(),
  };
}

// ─────────────────────────────────────────────────────────────
//  4) تقرير KPI للموظف — EmployeeKpiReport (§23)
//     Projection of the SAME typed report the tab renders — no
//     refetch, no fabrication (missing = '—').
// ─────────────────────────────────────────────────────────────

interface EmployeeKpiReportLike {
  employee?: {
    employeeName?: string | null;
    employeeCode?: string | null;
    department?: string | null;
    team?: string | null;
    position?: string | null;
  };
  period?: { valueBasis?: string; asOfDate?: string | null };
  scheme?: {
    schemeName?: string;
    schemeVersion?: string | number;
    qualityWeight?: number | null;
    frozen?: boolean;
  } | null;
  quality?: {
    rawScore?: number | null;
    weight?: number | null;
    weightedContribution?: number | null;
    maxContribution?: number | null;
    status?: string | null;
  } | null;
  overallStatus?: string | null;
  message?: string | null;
  weightedTotal?: number | null;
  availableWeight?: number | null;
  components?: Array<{
    componentId?: string;
    name?: string;
    weight?: number | null;
    rawScore?: number | null;
    weightedContribution?: number | null;
    maxContribution?: number | null;
    status?: string | null;
  }>;
  trend?: {
    months?: Array<{
      monthKey?: string;
      available?: boolean;
      rawScore?: number | null;
      weightedContribution?: number | null;
      weight?: number | null;
      valueBasis?: string;
      finalized?: boolean;
      rowStatus?: string | null;
    }>;
    mom?: { previousMonth?: string; deltaPoints?: number } | null;
  };
  evidence?: {
    counts?: { total?: number; approved?: number; pending?: number; rejected?: number; scoring?: number };
    observations?: Array<{
      observationDate?: string;
      categoryName?: string;
      severity?: string;
      notes?: string | null;
      status?: string;
      approvalStatus?: string;
      effect?: { applies?: boolean; counted?: boolean; signedPoints?: number };
      evidence?: { kind?: string; text?: string | null; url?: string | null };
      /** §EVIDENCE-ITEMS — COMPLETE canonical collection (all items). */
      evidenceItems?: EvidenceItem[];
      relatedCapaId?: string | null;
    }>;
  };
  traceability?: {
    origin?: string | null;
    deductionPoints?: number | null;
    bonusPoints?: number | null;
  } | null;
}

const COMPONENT_STATUS: Record<string, [string, string]> = {
  AVAILABLE: ['متاح', 'Available'], ZERO: ['صفر', 'Zero'], PENDING: ['غير متاح', 'N/A'], NOT_ELIGIBLE: ['غير مؤهل', 'Not eligible'],
  INCOMPLETE: ['جزئي', 'Partial'], FINALIZED: ['مجمّد', 'Frozen'],
};

export function employeeKpiReportToPrintModel(
  report: EmployeeKpiReportLike,
  monthKey: string,
): PrintReportModel {
  const sections: PrintSection[] = [];

  const components = report.components ?? [];
  if (components.length > 0) {
    sections.push({
      heading: 'مكونات KPI',
      table: {
        columns: ['المكون', 'الوزن', 'الدرجة الخام', 'المساهمة', 'الحالة'],
        rows: components.map((c) => [
          c.name ?? '—',
          c.weight == null ? '—' : `${c.weight}%`,
          c.rawScore === null || c.rawScore === undefined ? ui('غير متاح', 'N/A') : pct(c.rawScore),
          c.weightedContribution === null || c.weightedContribution === undefined
            ? ui('غير متاح', 'N/A')
            : `${num(c.weightedContribution)} / ${c.maxContribution ?? '—'}`,
          uiMap(COMPONENT_STATUS, c.status, dash(c.status)),
        ]),
      },
    });
  }

  const points = report.trend?.months ?? [];
  if (points.length > 0) {
    sections.push({
      heading: 'الاتجاه الشهري — درجة الجودة',
      table: {
        columns: ['الشهر', 'الدرجة الخام', 'المساهمة', 'الأساس', 'الحالة'],
        rows: points.map((p) => [
          monthLabel(p.monthKey) ?? dash(p.monthKey),
          p.available ? pct(p.rawScore) : ui('غير متاح', 'N/A'),
          p.available && p.weightedContribution !== null && p.weightedContribution !== undefined
            ? `${num(p.weightedContribution)} / ${p.weight ?? '—'}`
            : '—',
          dash(p.valueBasis),
          p.available ? (p.finalized ? ui('مجمّدة', 'Frozen') : ui('مفتوحة', 'Open')) : dash(p.rowStatus),
        ]),
      },
    });
  }

  const evidence = report.evidence;
  if (evidence?.observations && evidence.observations.length > 0) {
    // §EVIDENCE-PRESENTATION — the evidence column previously dropped
    // entirely in print; it now carries the COMPLETE collection as
    // numbered text (all items, stored order — links/numbers/image
    // authorized URLs). The shared print-table model carries
    // pre-formatted strings, so URLs print as readable text rather
    // than live anchors — the documented limitation of this renderer;
    // no image bytes are embedded to work around it.
    sections.push({
      heading: 'أدلة الجودة (الملاحظات)',
      table: {
        columns: ['التاريخ', 'التصنيف', 'الخطورة', 'الوصف', 'الحالة', 'الأثر', 'الدليل'],
        rows: evidence.observations.map((o) => [
          dash(o.observationDate),
          storedLabel(o.categoryName),
          dash(o.severity),
          dash(o.notes),
          dash(o.approvalStatus ?? o.status),
          o.effect?.counted
            ? (o.effect.signedPoints ?? 0 >= 0 ? `+${num(o.effect.signedPoints)}` : num(o.effect.signedPoints))
            : o.effect?.applies ? ui('بانتظار الاعتماد', 'Pending approval') : ui('لا يؤثر', 'No effect'),
          formatEvidenceItemsAsText(o.evidenceItems ?? []) || '—',
        ]),
      },
    });
  }

  const scheme = report.scheme;
  return {
    title: 'تقرير KPI للموظف',
    subject: [
      report.employee?.employeeName,
      (report.employee as { employeeCode?: string | null } | undefined)?.employeeCode,
      report.employee?.department,
      report.employee?.position,
    ].filter(Boolean).join(' — '),
    identity: {
      name: report.employee?.employeeName,
      code: (report.employee as { employeeCode?: string | null } | undefined)?.employeeCode,
      position: report.employee?.position ?? null,
      team: (report.employee as { team?: string | null } | undefined)?.team ?? null,
      department: report.employee?.department ?? null,
    },
    period: monthLabel(monthKey) || monthKey,
    generatedAt: undefined,
    stats: [
      { label: 'درجة الجودة (خام)', value: pct(report.quality?.rawScore) },
      { label: 'مساهمة الجودة', value: num(report.quality?.weightedContribution) },
      { label: 'نسبة الجودة', value: pct(report.quality?.weight) },
      { label: 'KPI الشركة', value: report.overallStatus === 'COMPLETE' ? ui('مكتمل', 'Complete') : dash(report.overallStatus) },
      { label: 'ملاحظات (أدلة)', value: num(evidence?.counts?.total) },
      { label: 'معتمدة', value: num(evidence?.counts?.approved) },
    ],
    sections,
    footerNote: scheme
      ? `مخطط KPI: ${scheme.schemeName ?? '—'} (v${scheme.schemeVersion ?? '—'})${scheme.qualityWeight != null ? ` — نسبة الجودة: ${scheme.qualityWeight}%` : ''}${scheme.frozen ? ' — قيم مجمّدة من إغلاق الشهر' : ''}`
      : undefined,
  };
}

// ─────────────────────────────────────────────────────────────
//  5) Generic TABLE report — ReportView (definition-driven pages)
//     Projects any columns/rows matrix into the clean A4 document.
// ─────────────────────────────────────────────────────────────

export function tableToPrintModel(input: {
  title: string;
  subject?: string;
  identity?: PrintReportModel['identity'];
  period?: string;
  columns: string[];
  rows: Array<Array<string | number>>;
  stats?: PrintReportModel['stats'];
  footerNote?: string;
  /** Column indexes that must render LTR (numbers/ids). */
  ltrColumns?: number[];
}): PrintReportModel {
  return {
    title: input.title,
    subject: input.subject,
    identity: input.identity,
    period: input.period,
    generatedAt: new Date().toISOString(),
    stats: input.stats,
    sections: [
      {
        table: {
          columns: input.columns,
          rows: input.rows,
          ltrColumns: input.ltrColumns,
        },
      },
    ],
    footerNote: input.footerNote ?? ui('تقرير رسمي — مصدر البيانات: قاعدة بيانات النظام للفترة المحددة.', 'Official report — data source: the system database for the selected period.'),
  };
}

// ─────────────────────────────────────────────────────────────
//  4) تقرير الموارد البشرية — HR Monthly Employee Performance
//
//     Pure projection of the ALREADY-SANITIZED HR view model
//     (/api/reports/hr-performance). The server structurally
//     excludes technical evidence from that payload, so printing
//     this model can never leak technical detail. Missing values
//     render '—', never fabricated.
// ─────────────────────────────────────────────────────────────

interface HrPerformanceRowLike {
  employeeName?: string | null;
  employeeCode?: string | null;
  department?: string | null;
  team?: string | null;
  position?: string | null;
  employmentStatus?: string | null;
  performanceScore?: number | null;
  performanceStatus?: string | null;
  schemeName?: string | null;
}

interface HrPerformanceReportLike {
  monthKey?: string;
  finalized?: boolean;
  rows?: HrPerformanceRowLike[];
  totals?: Partial<Record<'employees' | 'withResult' | 'pending' | 'incomplete' | 'finalized' | 'noScheme', number>>;
  generatedAt?: string;
}

const HR_EMPLOYMENT: Record<string, [string, string]> = {
  active: ['نشط', 'Active'], inactive: ['غير نشط', 'Inactive'], archived: ['مؤرشف', 'Archived'], unknown: ['—', '—'],
};

export function hrPerformanceToPrintModel(report: HrPerformanceReportLike): PrintReportModel {
  const rows = (report.rows ?? []).map((r) => [
    r.employeeName ?? '—',
    r.employeeCode ?? '—',
    r.department ?? '—',
    r.team ?? '—',
    r.position ?? '—',
    uiMap(HR_EMPLOYMENT, r.employmentStatus, '—'),
    r.performanceScore === null || r.performanceScore === undefined ? '—' : pct(r.performanceScore),
    r.performanceStatus ?? '—',
  ]);
  const t = report.totals ?? {};
  return {
    title: 'تقرير أداء الموظفين الشهري — الموارد البشرية',
    period: monthLabel(report.monthKey),
    generatedAt: report.generatedAt,
    stats: [
      { label: 'الموظفون', value: num(t.employees ?? 0) },
      { label: 'بنتيجة أداء', value: num(t.withResult ?? 0) },
      { label: 'معلّق', value: num(t.pending ?? 0) },
      { label: 'غير مكتمل', value: num(t.incomplete ?? 0) },
      { label: 'مجمّد', value: num(t.finalized ?? 0) },
    ],
    sections: [
      {
        table: {
          columns: ['الموظف', 'الكود', 'القسم', 'الفريق', 'الوظيفة', 'حالة العمل', 'نتيجة الأداء', 'الحالة'],
          rows,
          ltrColumns: [1, 6],
        },
      },
    ],
    footerNote: ui(
      'تقرير الموارد البشرية — نتيجة الأداء النهائية والسياق التنظيمي فقط. مصدر النتائج: خط مؤشرات الأداء القانوني للنظام (قيم حرفية بلا إعادة حساب).',
      'HR report — final performance results and organizational context only. Source: the system canonical KPI line (literal values, never recomputed).',
    ),
  };
}

// ─────────────────────────────────────────────────────────────
//  7) قرار دعم الموارد البشرية — HR Decision-Support
//
//     Pure projections of the ALREADY-SANITIZED decision view
//     models (/api/reports/hr-performance/decision[/employee]).
//     The server structurally excludes technical evidence from
//     those payloads, so printing these models can never leak
//     technical detail. Missing values render '—', never
//     fabricated; the safety disclaimer is ALWAYS present.
// ─────────────────────────────────────────────────────────────

const HR_DECISION_STATUS: Record<string, [string, string]> = {
  STABLE: ['مستقر', 'Stable'],
  IMPROVING: ['يتحسّن', 'Improving'],
  NEEDS_COACHING: ['يحتاج توجيهاً/تدريباً', 'Needs coaching/training'],
  PERFORMANCE_IMPROVEMENT_REVIEW: ['مراجعة خطة تحسين الأداء', 'Performance improvement plan review'],
  MANAGEMENT_REVIEW: ['مراجعة من الإدارة والموارد البشرية', 'Management & HR review'],
};

const HR_ACTION: Record<string, [string, string]> = {
  CONTINUE_MONITORING: ['متابعة دورية اعتيادية', 'Routine periodic follow-up'],
  RECOGNIZE_IMPROVEMENT: ['متابعة مع تشجيع التحسّن', 'Follow-up with encouragement'],
  COACHING: ['توجيه/تدريب موجّه', 'Targeted coaching/training'],
  IMPROVEMENT_PLAN: ['مراجعة أداء رسمية / خطة تحسين', 'Formal performance review / improvement plan'],
  MANAGEMENT_HR_REVIEW: ['مراجعة الإدارة والموارد البشرية', 'Management & HR review'],
};

const HR_TREND: Record<string, [string, string]> = {
  UP: ['تحسّن', 'Improving'], DOWN: ['تراجع', 'Declining'], STABLE: ['مستقر', 'Stable'],
};

const HR_SEVERITY: Record<string, [string, string]> = {
  HIGH: ['مرتفعة', 'High'], MEDIUM: ['متوسطة', 'Medium'], LOW: ['منخفضة', 'Low'],
};

/** System-generated review disclaimer — system UI vocabulary, locale-aware. */
export const hrDecisionDisclaimer = (): string =>
  ui(
    'توصية مراجعة إجرائية فقط — ليست قراراً نهائياً بشأن التوظيف. ' +
    'أي قرار نهائي يبقى قراراً بشرياً تتخذه الإدارة/الموارد البشرية خارج نظام التقييم الآلي.',
    'Procedural review recommendation only — not a final employment decision. ' +
    'Any final decision remains a human one made by management/HR outside the automated evaluation system.',
  );

interface HrDecisionRowLike {
  employeeName?: string | null;
  employeeCode?: string | null;
  department?: string | null;
  team?: string | null;
  status?: string | null;
  actionKind?: string | null;
  kpiScore?: number | null;
  trendDirection?: string | null;
}

interface HrDecisionReportLike {
  monthKey?: string;
  rows?: HrDecisionRowLike[];
  totals?: Partial<Record<
    'employees' | 'stable' | 'improving' | 'needsCoaching'
    | 'performanceImprovementReview' | 'managementReview' | 'withKpiResult' | 'averageKpi',
    number | null
  >>;
  operational?: {
    followUps?: { averageCompletionRate?: number | null; totalOverdue?: number | null };
    attendance?: { averageCompliance?: number | null; totalLateDays?: number | null; totalAbsentDays?: number | null };
    productivity?: { employeesWithDeals?: number | null; travelVolume?: number | null; closedDeals?: number | null };
    trend?: { improving?: number; stable?: number; declining?: number; noData?: number };
  };
  generatedAt?: string;
}

/** Team/department decision report → print (distributions, never a leaderboard). */
export function hrDecisionToPrintModel(report: HrDecisionReportLike): PrintReportModel {
  const t = report.totals ?? {};
  const o = report.operational ?? {};
  const rows = (report.rows ?? []).map((r) => [
    r.employeeName ?? '—',
    r.employeeCode ?? '—',
    r.department ?? '—',
    r.team ?? '—',
    uiMap(HR_DECISION_STATUS, r.status, r.status ?? '—'),
    uiMap(HR_ACTION, r.actionKind, '—'),
    r.kpiScore === null || r.kpiScore === undefined ? '—' : pct(r.kpiScore),
    r.trendDirection ? uiMap(HR_TREND, r.trendDirection, '—') : '—',
  ]);
  const trend = o.trend ?? {};
  return {
    title: 'تقرير دعم قرارات الأداء — الموارد البشرية',
    period: monthLabel(report.monthKey),
    generatedAt: report.generatedAt,
    stats: [
      { label: 'الموظفون', value: num(t.employees ?? 0) },
      { label: 'مستقر', value: num(t.stable ?? 0) },
      { label: 'يتحسّن', value: num(t.improving ?? 0) },
      { label: 'يحتاج توجيهاً', value: num(t.needsCoaching ?? 0) },
      { label: 'مراجعة تحسين أداء', value: num(t.performanceImprovementReview ?? 0) },
      { label: 'مراجعة إدارة', value: num(t.managementReview ?? 0) },
      { label: 'متوسط الأداء', value: t.averageKpi === null || t.averageKpi === undefined ? '—' : pct(t.averageKpi) },
    ],
    sections: [
      {
        table: {
          columns: ['الموظف', 'الكود', 'القسم', 'الفريق', 'الحالة', 'الإجراء المقترح', 'نتيجة الأداء', 'الاتجاه'],
          rows,
          ltrColumns: [1, 6],
        },
      },
      {
        heading: 'مؤشرات تشغيلية مجمّعة',
        stats: [
          { label: 'متوسط إنجاز المتابعات', value: o.followUps?.averageCompletionRate == null ? '—' : pct(o.followUps.averageCompletionRate) },
          { label: 'إجمالي المتابعات المتأخرة', value: num(o.followUps?.totalOverdue ?? 0) },
          { label: 'متوسط الالتزام بالحضور', value: o.attendance?.averageCompliance == null ? '—' : pct(o.attendance.averageCompliance) },
          // §DEAL-DATES — the two canonical deal dimensions, same
          // numbers the UI card shows (never recomputed here).
          { label: 'صفقات مكتملة (تاريخ الإغلاق)', value: num(o.productivity?.closedDeals ?? 0) },
          { label: 'حجم السفر (تاريخ المغادرة)', value: num(o.productivity?.travelVolume ?? 0) },
          { label: 'اتجاه التحسّن/التراجع', value: `${num(trend.improving ?? 0)} / ${num(trend.declining ?? 0)}` },
        ],
      },
    ],
    footerNote: hrDecisionDisclaimer(),
  };
}

interface HrDecisionFactorLike {
  category?: string | null;
  kind?: string | null;
  severity?: string | null;
  signalAr?: string | null;
  value?: number | null;
  comparisonAr?: string | null;
}

const HR_FACTOR_CATEGORY: Record<string, [string, string]> = {
  KPI: ['مؤشر الأداء', 'Performance KPI'],
  FOLLOW_UP: ['المتابعات اليومية', 'Daily follow-ups'],
  PRODUCTIVITY: ['الإنتاجية', 'Productivity'],
  QUALITY: ['إشارة الجودة', 'Quality signal'],
  ATTENDANCE: ['الانضباط والحضور', 'Attendance discipline'],
  HR_DISCIPLINARY: ['إشارة الموارد البشرية', 'HR signal'],
  TREND: ['الاتجاه الزمني', 'Time trend'],
};

interface HrDecisionEmployeeReportLike {
  monthKey?: string;
  employee?: {
    employeeName?: string | null;
    employeeCode?: string | null;
    department?: string | null;
    team?: string | null;
    position?: string | null;
  };
  executive?: {
    status?: string | null;
    kpiScore?: number | null;
    trendDirection?: string | null;
    riskLevel?: string | null;
  };
  scorecard?: Array<{
    labelAr?: string | null;
    availability?: string | null;
    unavailableReasonAr?: string | null;
    state?: string | null;
    metrics?: Array<{ labelAr?: string | null; value?: number | null; unit?: string | null; hintAr?: string | null }>;
  }>;
  trend?: {
    points?: Array<{ monthKey?: string; available?: boolean; rawScore?: number | null }>;
    direction?: string | null;
    consecutiveBelowTarget?: number;
    targetScore?: number;
  };
  strengths?: HrDecisionFactorLike[];
  concerns?: HrDecisionFactorLike[];
  action?: { actionAr?: string | null; rationaleAr?: string | null; disclaimerAr?: string | null };
  dataQuality?: { notesAr?: string[] };
  generatedAt?: string;
}

function factorRows(factors?: HrDecisionFactorLike[]): string[][] {
  return (factors ?? []).map((f) => [
    uiMap(HR_FACTOR_CATEGORY, f.category, f.category ?? '—'),
    f.kind === 'POSITIVE' ? ui('إيجابية', 'Positive') : ui('سلبية', 'Negative'),
    uiMap(HR_SEVERITY, f.severity, f.severity ?? '—'),
    f.signalAr ?? '—',
    f.value === null || f.value === undefined ? '—' : String(f.value),
    f.comparisonAr ?? '—',
  ]);
}

function formatMetricValue(value: number | null | undefined, unit: string | null | undefined): string {
  if (value === null || value === undefined) return '—';
  if (unit === 'percent') return pct(value);
  if (unit === 'days') return `${num(value)} ${ui('يوم', 'day(s)')}`;
  if (unit === 'minutes') return `${num(value)} ${ui('دقيقة', 'minute(s)')}`;
  return num(value);
}

function scorecardStateAr(entry: NonNullable<HrDecisionEmployeeReportLike['scorecard']>[number]): string {
  if (entry.availability === 'NOT_AVAILABLE') return ui('غير متاح', 'N/A');
  switch (entry.state) {
    case 'WEAK': return ui('ضعيف', 'Weak');
    case 'WATCH': return ui('للمراقبة', 'Watch');
    case 'POSITIVE': return ui('إيجابي', 'Positive');
    case 'OK': return ui('سليم', 'Sound');
    default: return ui('بلا حكم', 'No verdict');
  }
}

/** Per-employee decision report → print (the full HR-safe evidence). */
export function hrDecisionEmployeeToPrintModel(report: HrDecisionEmployeeReportLike): PrintReportModel {
  const e = report.employee ?? {};
  const x = report.executive ?? {};
  const sections: PrintSection[] = [];

  sections.push({
    heading: 'بطاقة الأداء',
    table: {
      columns: ['البُعد', 'الحالة', 'المؤشرات'],
      rows: (report.scorecard ?? []).map((entry) => [
        entry.labelAr ?? '—',
        scorecardStateAr(entry),
        (entry.metrics ?? [])
          .map((m) => `${m.labelAr ?? ''}: ${formatMetricValue(m.value, m.unit)}${m.hintAr ? ` (${m.hintAr})` : ''}`)
          .join(' — ') || (entry.unavailableReasonAr ?? '—'),
      ]),
    },
  });

  const trendPoints = (report.trend?.points ?? [])
    .map((p) => `${p.monthKey ?? '—'}: ${p.available && p.rawScore !== null && p.rawScore !== undefined ? pct(p.rawScore) : ui('غير متاح', 'N/A')}`)
    .join(' | ');
  sections.push({
    heading: 'الاتجاه الزمني',
    paragraphs: [
      trendPoints || '—',
      `${ui('الاتجاه', 'Trend')}: ${report.trend?.direction ? uiMap(HR_TREND, report.trend.direction, '—') : '—'}`
        + ` ${ui('— أشهر متتالية تحت الهدف:', '— consecutive months below target:')} ${num(report.trend?.consecutiveBelowTarget ?? 0)}`
        + ` (الهدف المُهيّأ ${report.trend?.targetScore === null || report.trend?.targetScore === undefined ? '—' : pct(report.trend.targetScore)})`,
    ],
  });

  const factorColumns = ['البُعد', 'النوع', 'الشدة', 'الإشارة', 'القيمة', 'المقارنة'];
  sections.push({
    heading: 'نقاط القوة (من إشارات مقاسة)',
    table: { columns: factorColumns, rows: factorRows(report.strengths) },
  });
  sections.push({
    heading: 'مواطن الاهتمام (من إشارات مقاسة)',
    table: { columns: factorColumns, rows: factorRows(report.concerns) },
  });

  if ((report.dataQuality?.notesAr ?? []).length > 0) {
    sections.push({ heading: 'جودة البيانات', paragraphs: report.dataQuality?.notesAr ?? [] });
  }

  return {
    title: 'تقرير دعم قرار أداء موظف — الموارد البشرية',
    identity: {
      name: e.employeeName ?? undefined,
      code: e.employeeCode ?? undefined,
      department: e.department ?? undefined,
      team: e.team ?? undefined,
      position: e.position ?? undefined,
    },
    period: monthLabel(report.monthKey),
    generatedAt: report.generatedAt,
    stats: [
      { label: 'الحالة', value: uiMap(HR_DECISION_STATUS, x.status, '—') },
      { label: 'نتيجة الأداء', value: x.kpiScore === null || x.kpiScore === undefined ? '—' : pct(x.kpiScore) },
      { label: 'الاتجاه', value: x.trendDirection ? uiMap(HR_TREND, x.trendDirection, '—') : '—'},
      // §PRESENTATION-BOUNDARY — the risk-level key renders as its
      // localized business label, never raw.
      { label: 'مستوى المخاطر', value: x.riskLevel ? presentStatus(x.riskLevel, displayLocale() === 'en' ? 'en' : 'ar') : '—' },
    ],
    sections,
    footerNote: `${report.action?.actionAr ?? '—'} — ${report.action?.rationaleAr ?? ''} · ${report.action?.disclaimerAr ?? hrDecisionDisclaimer()}`,
  };
}

// ─────────────────────────────────────────────────────────────
//  8) مساحة ذكاء الأداء — KPI Reports 2.0 insights workspace
//
//     Pure projection of the ALREADY-BUILT KpiInsightsReport (the
//     canonical insights assembly). Percentage terminology only —
//     no weight/contribution wording on paper (spec §25). Missing
//     data renders '—', never 0.
// ─────────────────────────────────────────────────────────────

interface InsightsRowLike {
  employeeName?: string | null;
  employeeCode?: string | null;
  department?: string | null;
  team?: string | null;
  quality?: { rawScore?: number | null } | null;
  rowStatus?: string | null;
}

interface InsightsReportLike {
  reportKind?: 'INSIGHTS';
  monthKey?: string;
  valueBasis?: string;
  statisticsKind?: string;
  selection?: { employeeCount?: number; teamLabels?: string[]; departmentLabels?: string[] };
  overview?: {
    avgQuality?: number | null;
    qualityDeltaPoints?: number | null;
    observationsApproved?: number;
    observationsPending?: number;
    observationsRejected?: number;
    repeatedIssues?: number;
    highCritical?: number;
    needsAttention?: number;
  };
  rows?: InsightsRowLike[];
  teamUnits?: Array<{
    key?: string; label?: string; employeeCount?: number;
    avgQuality?: number | null; deltaPoints?: number | null;
    observationsApproved?: number; repeatedIssues?: number; highCritical?: number;
    improving?: number; declining?: number;
  }>;
  categoryDistribution?: Array<{ label?: string; count?: number; pct?: number | null }>;
  severityDistribution?: Array<{ severity?: string; count?: number; pct?: number | null }>;
  repeatedIssues?: Array<{
    label?: string; occurrenceCount?: number; employeeCount?: number;
    affectedTeamLabels?: string[]; firstOccurrence?: string | null; lastOccurrence?: string | null;
  }>;
  opportunities?: Array<{
    label?: string; occurrenceCount?: number; employeeCount?: number; teamCount?: number; changePct?: number | null;
  }>;
  dataQuality?: Array<{ source?: string; status?: string }>;
  generatedAt?: string;
}

const INSIGHTS_SEVERITY: Record<string, [string, string]> = {
  low: ['منخفضة', 'Low'], medium: ['متوسطة', 'Medium'], high: ['مرتفعة', 'High'], critical: ['حرجة', 'Critical'],
};

const INSIGHTS_DATA_SOURCE: Record<string, [string, string]> = {
  kpi: ['إطار KPI', 'KPI framework'],
  quality: ['ملاحظات الجودة', 'Quality observations'],
  followUps: ['المتابعات', 'Follow-ups'],
  complaints: ['الشكاوى', 'Complaints'],
  capa: ['تحليل المشكلات (CAPA)', 'CAPA'],
  attendance: ['الحضور والانصراف', 'Attendance'],
  hrDeductions: ['خصومات الموارد البشرية', 'HR deductions'],
};

const INSIGHTS_DATA_STATUS: Record<string, [string, string]> = {
  available: ['متاح', 'Available'],
  no_data: ['لا توجد بيانات', 'No data'],
  not_configured: ['غير مُهيأ', 'Not configured'],
  restricted: ['محجوب — لا صلاحية', 'Withheld — no permission'],
};

/** KPI Reports 2.0 insights workspace → print. */
export function kpiInsightsToPrintModel(
  report: InsightsReportLike,
  subject?: string,
): PrintReportModel {
  const o = report.overview ?? {};
  const delta = o.qualityDeltaPoints;

  const employeeRows = (report.rows ?? []).map((r) => [
    r.employeeName ?? '—',
    r.employeeCode ?? '—',
    r.department ?? '—',
    r.team ?? '—',
    r.quality?.rawScore === null || r.quality?.rawScore === undefined ? '—' : pct(r.quality!.rawScore!),
    presentStatus(r.rowStatus ?? '', displayLocale() === 'en' ? 'en' : 'ar'),
  ]);

  const sections: PrintSection[] = [];

  sections.push({
    heading: ui('أداء الموظفين', 'Employee performance'),
    table: {
      columns: [
        ui('الموظف', 'Employee'), ui('الكود', 'Code'), ui('القسم', 'Department'), ui('الفريق', 'Team'),
        ui('نسبة الجودة', 'Quality %'), ui('حالة التقييم', 'Evaluation status'),
      ],
      rows: employeeRows,
      ltrColumns: [1, 4],
    },
  });

  if ((report.teamUnits ?? []).length > 0) {
    sections.push({
      heading: ui('الفرق كوحدات تشغيلية', 'Teams as operating units'),
      table: {
        columns: [
          ui('الفريق', 'Team'), ui('الموظفون', 'Employees'), ui('متوسط نسبة الجودة', 'Avg quality'),
          ui('التغير', 'Change'), ui('الملاحظات المعتمدة', 'Approved obs'),
          ui('مشكلات متكررة', 'Repeated'), ui('مرتفعة/حرجة', 'High/Crit'),
        ],
        rows: (report.teamUnits ?? []).map((u) => [
          u.label ?? u.key ?? '—',
          num(u.employeeCount ?? 0),
          u.avgQuality === null || u.avgQuality === undefined ? '—' : pct(u.avgQuality),
          u.deltaPoints === null || u.deltaPoints === undefined ? '—' : `${u.deltaPoints > 0 ? '+' : ''}${u.deltaPoints}`,
          num(u.observationsApproved ?? 0),
          num(u.repeatedIssues ?? 0),
          num(u.highCritical ?? 0),
        ]),
        ltrColumns: [1, 2, 3, 4, 5, 6],
      },
    });
  }

  if ((report.categoryDistribution ?? []).length > 0) {
    sections.push({
      heading: ui('التوزيع حسب التصنيف (الملاحظات المعتمدة)', 'Distribution by category (approved observations)'),
      table: {
        columns: [ui('التصنيف', 'Category'), ui('العدد', 'Count'), ui('النسبة', 'Share')],
        rows: (report.categoryDistribution ?? []).map((c) => [
          c.label ?? '—',
          num(c.count ?? 0),
          c.pct === null || c.pct === undefined ? '—' : pct(c.pct),
        ]),
        ltrColumns: [1, 2],
      },
    });
  }

  if ((report.repeatedIssues ?? []).length > 0) {
    sections.push({
      heading: ui('المشكلات المتكررة', 'Repeated issues'),
      table: {
        columns: [
          ui('التصنيف', 'Category'), ui('مرات التكرار', 'Occurrences'), ui('موظفون متأثرون', 'Employees affected'),
          ui('الفرق', 'Teams'), ui('أول ظهور', 'First'), ui('آخر ظهور', 'Last'),
        ],
        rows: (report.repeatedIssues ?? []).map((g) => [
          g.label ?? '—',
          num(g.occurrenceCount ?? 0),
          num(g.employeeCount ?? 0),
          (g.affectedTeamLabels ?? []).join(' · ') || '—',
          g.firstOccurrence ?? '—',
          g.lastOccurrence ?? '—',
        ]),
        ltrColumns: [1, 2, 4, 5],
      },
    });
  }

  if ((report.opportunities ?? []).length > 0) {
    sections.push({
      heading: ui('فرص التحسين التشغيلي (أنماط متكررة — مؤشر مراجعة، لا سبب نهائي)',
        'Operational improvement opportunities (repeated patterns — review indicators, not final causes)'),
      table: {
        columns: [
          ui('المجال', 'Area'), ui('مرات التكرار', 'Occurrences'), ui('موظفون', 'Employees'),
          ui('فرق', 'Teams'), ui('التغير عن الفترة السابقة', 'Change vs previous'),
        ],
        rows: (report.opportunities ?? []).map((op) => [
          op.label ?? '—',
          num(op.occurrenceCount ?? 0),
          num(op.employeeCount ?? 0),
          num(op.teamCount ?? 0),
          op.changePct === null || op.changePct === undefined ? '—' : `${op.changePct > 0 ? '+' : ''}${op.changePct}%`,
        ]),
        ltrColumns: [1, 2, 3, 4],
      },
    });
  }

  sections.push({
    heading: ui('جودة البيانات', 'Data quality'),
    table: {
      columns: [ui('المصدر', 'Source'), ui('الحالة', 'Status')],
      rows: (report.dataQuality ?? []).map((entry) => [
        uiMap(INSIGHTS_DATA_SOURCE, entry.source ?? '', entry.source ?? '—'),
        uiMap(INSIGHTS_DATA_STATUS, entry.status ?? '', entry.status ?? '—'),
      ]),
    },
  });

  const severityStats = (report.severityDistribution ?? []).map((s) => ({
    label: uiMap(INSIGHTS_SEVERITY, s.severity ?? '', s.severity ?? '—'),
    value: num(s.count ?? 0),
    hint: s.pct === null || s.pct === undefined ? undefined : `${s.pct}%`,
  }));

  return {
    title: ui('تقرير الأداء التشغيلي', 'Operational Performance Report'),
    subject: subject ?? undefined,
    period: monthLabel(report.monthKey),
    generatedAt: report.generatedAt,
    stats: [
      { label: ui('الموظفون', 'Employees'), value: num(report.selection?.employeeCount ?? 0) },
      { label: ui('متوسط نسبة الجودة', 'Average quality'), value: o.avgQuality === null || o.avgQuality === undefined ? '—' : pct(o.avgQuality) },
      { label: ui('التغير عن الفترة السابقة', 'Change vs previous'), value: delta === null || delta === undefined ? '—' : `${delta > 0 ? '+' : ''}${delta}` },
      { label: ui('الملاحظات المعتمدة', 'Approved observations'), value: num(o.observationsApproved ?? 0) },
      { label: ui('مشكلات متكررة', 'Repeated issues'), value: num(o.repeatedIssues ?? 0) },
      { label: ui('بحاجة إلى متابعة', 'Needs attention'), value: num(o.needsAttention ?? 0) },
      ...severityStats,
    ],
    sections,
    footerNote: reportSourceFooter(),
  };
}

// ─────────────────────────────────────────────────────────────
//  4) §FLEX-PERIODS — flexible-period insights report
// ─────────────────────────────────────────────────────────────

import type { FlexibleKpiInsightsReport, FlexibleSpanMeta } from '@/lib/kpi-reporting';

function formatMonthCellFlexible(monthKey: string, report: FlexibleKpiInsightsReport): string {
  const all = [...report.period.monthBases, ...(report.comparison?.monthBases ?? [])];
  const basis = all.find((b) => b.monthKey === monthKey);
  if (!basis) return monthKey;
  const label = displayLocale() === 'en' ? monthKey : monthKey.replace('-', '/');
  return `${label}${basis.liveCalculated ? (displayLocale() === 'en' ? ' (live)' : ' (حية)') : ''}`;
}

function spanMetaText(meta: FlexibleSpanMeta, locale: 'ar' | 'en'): string {
  const from = meta.startDayKey.split('-').reverse().join('/');
  const to = meta.endDayKey.split('-').reverse().join('/');
  return `${from} → ${to} (${meta.dayCount} ${locale === 'en' ? 'days' : 'يومًا'})`;
}

const FLEX_BASIS_LABELS: Record<string, readonly [string, string]> = {
  FINALIZED: ['مجمّدة (أشهر مغلقة)', 'FINALIZED (closed months)'],
  MTD: ['حية حتى الآن (تشمل الشهر الحالي)', 'MTD (through now)'],
  LIVE: ['حية (حساب مباشر على نافذة الفترة)', 'LIVE (window calculation)'],
  MIXED: ['مختلطة (أشهر مجمّدة + حية)', 'MIXED (frozen + live months)'],
};

export function flexibleKpiInsightsToPrintModel(
  report: FlexibleKpiInsightsReport,
  subject?: string,
): PrintReportModel {
  const locale = displayLocale();
  const isEn = locale === 'en';
  const u = (ar: string, en: string) => (isEn ? en : ar);

  const sections: PrintSection[] = [];

  // ── Period header ──
  sections.push({
    heading: u('الفترة المرنة + المقارنة المستقلة', 'Flexible Period + Independent Comparison'),
    table: {
      columns: [u('النوع', 'Type'), u('المدى', 'Range'), u('الأيام', 'Days'), u('الأساس', 'Basis')],
      rows: [
        [
          u('فترة التقرير', 'Report period'),
          `${report.period.startDayKey} → ${report.period.endDayKey}`,
          String(report.period.dayCount),
          FLEX_BASIS_LABELS[report.period.valueBasis]?.[locale === 'en' ? 1 : 0] ?? report.period.valueBasis,
        ],
        [
          u('فترة المقارنة', 'Comparison period'),
          report.comparison ? `${report.comparison.startDayKey} → ${report.comparison.endDayKey}` : '—',
          report.comparison ? String(report.comparison.dayCount) : '—',
          report.comparison ? FLEX_BASIS_LABELS[report.comparison.valueBasis]?.[locale === 'en' ? 1 : 0] ?? report.comparison.valueBasis : '—',
        ],
      ],
    },
  });

  // ── Overview ──
  const o = report.overview;
  const delta = o.qualityDeltaPoints;
  sections.push({
    heading: u('ملخص مؤشر الجودة', 'Quality KPI Summary'),
    stats: [
      { label: u('متوسط الجودة', 'Avg quality'), value: o.averageQuality === null ? '—' : pct(o.averageQuality) },
      { label: u('متوسط المقارنة', 'Comparison avg'), value: o.previousAverageQuality === null ? '—' : pct(o.previousAverageQuality) },
      { label: u('التغير (نقاط)', 'Change (points)'), value: delta === null ? '—' : `${delta > 0 ? '+' : ''}${delta}` },
      { label: u('ملاحظات معتمدة', 'Approved observations'), value: num(o.observationsApproved ?? 0) },
      { label: u('عالية/حرجة', 'High/critical'), value: num(o.highCritical ?? 0) },
      { label: u('موظفون بقيمة', 'Employees with value'), value: `${num(o.employeesWithValue ?? 0)} / ${num(o.employeesEvaluated ?? 0)}` },
    ],
  });

  // ── Employee KPI table ──
  if (report.employees.length > 0) {
    sections.push({
      heading: u('أداء الموظفين خلال الفترة', 'Employee KPI across period'),
      table: {
        columns: [
          u('الموظف', 'Employee'),
          u('الفريق', 'Team'),
          u('القسم', 'Department'),
          u('الشركة', 'Company'),
          u('أشهر بقيمة', 'Months w/ value'),
          u('متوسط الفترة', 'Period avg'),
          u('متوسط المقارنة', 'Comparison avg'),
          u('التغير', 'Change'),
          u('ملاحظات معتمدة', 'Approved obs.'),
        ],
        rows: report.employees.map((e) => [
          e.employeeName,
          e.team ?? '—',
          e.department ?? '—',
          e.company ?? '—',
          String(e.monthsWithValue),
          e.averageQuality !== null ? pct(e.averageQuality) : '—',
          e.previousAverageQuality !== null ? pct(e.previousAverageQuality) : '—',
          e.deltaPoints === null ? '—' : `${e.deltaPoints > 0 ? '+' : ''}${e.deltaPoints}`,
          num(e.observationsApproved ?? 0),
        ]),
      },
    });
  }

  // ── Unit rollups ──
  if (report.units.length > 0) {
    sections.push({
      heading: u('مقارنة الوحدات (عضوية فعلية)', 'Unit Comparison (real membership)'),
      table: {
        columns: [
          u('النوع', 'Type'),
          u('الوحدة', 'Unit'),
          u('الأعضاء', 'Members'),
          u('ببيانات', 'With data'),
          u('متوسط الفترة', 'Period avg'),
          u('متوسط المقارنة', 'Comparison avg'),
          u('التغير', 'Change'),
          u('ملاحظات معتمدة', 'Approved obs.'),
          u('مشكلات متكررة', 'Repeated issues'),
        ],
        rows: report.units.map((unit) => [
          (UNIT_TYPE_LABELS[unit.unitType] ? (isEn ? UNIT_TYPE_LABELS[unit.unitType][1] : UNIT_TYPE_LABELS[unit.unitType][0]) : unit.unitType),
          unit.label,
          `${unit.employeeCount} (${unit.membersWithValue})`,
          unit.averageQuality !== null ? pct(unit.averageQuality) : '—',
          unit.previousAverageQuality !== null ? pct(unit.previousAverageQuality) : '—',
          unit.deltaPoints === null ? '—' : `${unit.deltaPoints > 0 ? '+' : ''}${unit.deltaPoints}`,
          num(unit.observationsApproved ?? 0),
          num(unit.repeatedIssues ?? 0),
        ]),
      },
    });
  }

  // ── Distributions ──
  sections.push({
    heading: u('توزيع الفئات / الخطورة / الخصومات', 'Category / Severity / Deductions'),
    table: {
      columns: [u('المجال', 'Area'), u('البيان', 'Item'), u('العدد', 'Count'), u('المقارنة', 'Comparison')],
      rows: [
        ...report.observations.byCategory.map((c) => [
          u('فئة', 'Category'),
          storedLabel(c.label),
          `${num(c.count)}${c.pct !== null ? ` (${c.pct}%)` : ''}`,
          c.previousCount !== null ? String(c.previousCount) : '—',
        ]),
        ...report.observations.bySeverity.map((s) => [
          u('خطورة', 'Severity'),
          u(s.severity === 'critical' ? 'حرجة' : s.severity === 'high' ? 'مرتفعة' : s.severity === 'medium' ? 'متوسطة' : 'منخفضة', s.severity === 'critical' ? 'Critical' : s.severity === 'high' ? 'High' : s.severity === 'medium' ? 'Medium' : 'Low'),
          `${num(s.count)}${s.pct !== null ? ` (${s.pct}%)` : ''}`,
          s.previousCount !== null ? String(s.previousCount) : '—',
        ]),
        ...report.deductions.byType.map((t) => [
          u('خصم', 'Deduction'),
          storedLabel(t.type),
          String(t.count),
          '—',
        ]),
      ],
    },
  });

  // ── Repeated issues ──
  if (report.observations.repeatedIssues.length > 0 || report.observations.windowRecurrence.length > 0) {
    sections.push({
      heading: u('المشكلات المتكررة', 'Repeated Issues'),
      table: {
        columns: [u('المشكلة', 'Issue'), u('النوع', 'Kind'), u('التكرارات', 'Occurrences'), u('موظفون', 'Employees'), u('أشهر', 'Months')],
        rows: [
          ...report.observations.repeatedIssues.map((g) => [
            storedLabel(g.label),
            u('داخل الفترة', 'In-period'),
            String(g.occurrenceCount),
            String(g.employeeCount),
            '—',
          ]),
          ...report.observations.windowRecurrence.map((g) => [
            storedLabel(g.label),
            u('عبر الأشهر', 'Across months'),
            String(g.occurrenceCount),
            String(g.monthsPresent),
            '—',
          ]),
        ],
      },
    });
  }

  // ── Data quality ──
  if (report.dataQuality.length > 0) {
    const human: Record<string, readonly [string, string]> = {
      observationsDateUnknown: ['ملاحظات بلا تاريخ صالح استُثنيت من النافذة', 'Observations without a valid date were excluded from the window'],
      mixedValueBasis: ['الفترة تجمع أشهرًا مجمّدة وأشهرًا حية — الأساس معلن لكل شهر', 'The span mixes frozen and live months — each month basis is disclosed'],
      liveCalculatedMonthsPresent: ['توجد أشهر بقيم حية (حساب مباشر)', 'Some months carry live (calculated) values'],
      deductionsRestricted: ['خصومات الجودة محجوبة لصلاحياتك', 'Quality deductions are restricted for your permissions'],
    };
    sections.push({
      heading: u('ملاحظات جودة البيانات', 'Data Quality Notes'),
      paragraphs: report.dataQuality.map((note) => {
        const key = note.split(':')[0] ?? '';
        const pair = human[key];
        return pair ? (locale === 'en' ? pair[1] : pair[0]) : note;
      }),
    });
  }

  return {
    title: u('تقرير الأداء المرن', 'Flexible Period Performance Report'),
    subject: undefined,
    period: `${report.period.startDayKey} → ${report.period.endDayKey} (${report.comparison ? `${report.comparison.startDayKey} → ${report.comparison.endDayKey}` : 'no comparison'})`,
    generatedAt: report.generatedAt,
    stats: [
      { label: u('فترة التقرير', 'Period'), value: `${report.period.startDayKey} → ${report.period.endDayKey} (${report.period.dayCount} ${u('أيام', 'days')})` },
      { label: u('فترة المقارنة', 'Comparison'), value: report.comparison ? `${report.comparison.startDayKey} → ${report.comparison.endDayKey} (${report.comparison.dayCount} ${u('أيام', 'days')})` : '—' },
      { label: u('متوسط الجودة', 'Avg quality'), value: report.overview.averageQuality === null ? '—' : pct(report.overview.averageQuality) },
      { label: u('متوسط المقارنة', 'Comparison avg'), value: report.overview.previousAverageQuality === null ? '—' : pct(report.overview.previousAverageQuality) },
      { label: u('التغير (نقاط)', 'Change (points)'), value: report.overview.qualityDeltaPoints === null ? '—' : `${report.overview.qualityDeltaPoints > 0 ? '+' : ''}${report.overview.qualityDeltaPoints}` },
    ],
    sections,
    footerNote: reportSourceFooter(),
  };
}
